import {api} from './shell.js';

const form = document.getElementById('hs-setup');
const confirmation = form.elements.confirmPassword;
function checkPassword() {
  confirmation.setCustomValidity(confirmation.value === form.elements.password.value ? '' : '確認用のパスワードが一致しません。');
}
confirmation.addEventListener('input', checkPassword);
form.elements.password.addEventListener('input', checkPassword);
form.addEventListener('submit', async event => {
  event.preventDefault();
  checkPassword();
  if (!form.reportValidity()) return;
  const button = form.querySelector('button');
  if (button.disabled) return;
  button.disabled = true;
  const message = document.getElementById('hs-message');
  message.textContent = '';
  try {
    await api('/api/setup', {method:'POST', json:Object.fromEntries(new FormData(form))});
    form.reset();
    location.replace('/');
  } catch (error) {
    message.textContent = error.status ? error.message : '接続できません。通信を確認してください。';
    if (error.status === 409) {
      form.elements.password.value = '';
      confirmation.value = '';
      const login = document.getElementById('hs-enter');
      login.hidden = false;
      login.focus();
    } else {
      button.disabled = false;
    }
  }
});
