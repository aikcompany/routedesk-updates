import {api} from './shell.js';

export function mountInvoiceSettings({saved, report}) {
  const form = document.getElementById('hs-invoice-form');
  const {elements} = form;
  const message = form.querySelector('[role=status]');
  const submit = form.querySelector('[type=submit]');
  const logoFile = elements.logoFile;
  const preview = document.getElementById('hs-logo-preview');
  const remove = document.getElementById('hs-remove-logo');
  const issuerFields = ['name','postal','address','tel','fax','registration','bankText','footNote'];
  const numericRules = ['taxRate','closingDay','payMonthOffset','payDay'];
  let baseline, originalText, logo, logoRead = 0;

  function showLogo(value) {
    logo = value || '';
    if (logo) preview.src = logo;
    else preview.removeAttribute('src');
    preview.hidden = remove.hidden = !logo;
  }
  function load(settings) {
    baseline = settings;
    for (const key of issuerFields) elements[key].value = settings.issuer[key] || '';
    // Textareas normalize line endings, so compare with the value initially displayed.
    originalText = Object.fromEntries(issuerFields.map(key => [key,elements[key].value]));
    for (const key of [...numericRules,'rounding','tollTaxable']) {
      elements[key].value = String(settings.invoiceRules[key]);
    }
    logoFile.value = '';
    showLogo(settings.issuer.logo);
    for (const fieldset of form.querySelectorAll('fieldset')) fieldset.disabled = false;
    submit.disabled = false;
  }
  logoFile.addEventListener('change', async () => {
    const ticket = ++logoRead;
    const file = logoFile.files[0];
    message.textContent = '';
    if (!file) { submit.disabled = false; return; }
    submit.disabled = true;
    try {
      if (file.size > 512 * 1024 || !['image/png','image/jpeg','image/webp'].includes(file.type)) {
        throw Error('512 KBまでのPNG・JPEG・WebPの画像を選んでください。');
      }
      const value = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(Error('画像を読み込めませんでした。'));
        reader.readAsDataURL(file);
      });
      if (ticket === logoRead) showLogo(value);
    } catch (error) {
      if (ticket === logoRead) { logoFile.value = ''; message.textContent = error.message; }
    } finally { if (ticket === logoRead) submit.disabled = false; }
  });
  remove.onclick = () => { logoRead++; logoFile.value = ''; showLogo(''); submit.disabled = false; };
  form.onsubmit = async event => {
    event.preventDefault();
    if (submit.disabled || !baseline) return;
    form.inert = submit.disabled = true;
    message.textContent = '';
    const issuer = {}, invoiceRules = {};
    for (const key of issuerFields) {
      if (elements[key].value !== originalText[key]) issuer[key] = elements[key].value;
    }
    if (logo !== (baseline.issuer.logo || '')) issuer.logo = logo;
    for (const key of [...numericRules,'rounding','tollTaxable']) {
      let value = elements[key].value;
      if (numericRules.includes(key)) value = Number(value);
      if (key === 'tollTaxable') value = value === 'true';
      if (value !== baseline.invoiceRules[key]) invoiceRules[key] = value;
    }
    try {
      const changes = {};
      if (Object.keys(issuer).length) changes.issuer = issuer;
      if (Object.keys(invoiceRules).length) changes.invoiceRules = invoiceRules;
      if (Object.keys(changes).length) {
        const {settings} = await api('/api/admin/settings', {method:'POST', json:changes});
        load(settings);
        saved(settings);
      }
      message.textContent = '請求書の設定を保存しました。';
    } catch (error) { report(error); }
    finally { form.inert = submit.disabled = false; }
  };
  return {load, setCompanyName(name) {
    if (!baseline) return;
    if (elements.name.value === originalText.name) elements.name.value = name;
    originalText.name = name;
  }};
}
