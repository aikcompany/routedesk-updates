import {api} from './shell.js';

const {driverAccount:account, driverId, company} = document.body.dataset;
const base = window.DRIVER_API;
const phases = ['start','load','arrive','done'];
const names = ['出発','積み終わり','卸し地に到着','完了'];
const actions = ['出発する','積み終わった','卸し地に着いた','卸し終わった（完了）'];
const acting = {'X-Acting-User':encodeURIComponent(account)};
const prefix = 'hs-step.v1.' + JSON.stringify([company, account, driverId]) + '.';
const byId = id => document.getElementById(id);
const message = byId('hs-driver-message');
const main = byId('main');
const tokyoDay = date => new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Tokyo'}).format(date);
function day(iso) {
  const date = new Date(iso + 'T12:00:00+09:00');
  return Number.isFinite(date.valueOf()) ? new Intl.DateTimeFormat('ja-JP',{timeZone:'Asia/Tokyo',month:'numeric',day:'numeric',weekday:'short'}).format(date) : '日付未定';
}
const clock = at => new Intl.DateTimeFormat('ja-JP',{timeZone:'Asia/Tokyo',hour:'2-digit',minute:'2-digit'}).format(new Date(at));
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let trips = [], tab = 'today', memoId, photoId, syncing = false, rerun = false, loaded = false;
let notice = '', retryTimer, retryDelay = 3000;

// Persist only unsent button presses. One key per press prevents tabs from
// overwriting each other's outbox. No trip response, note or image is stored.
function pending() {
  const result = [];
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key?.startsWith(prefix)) continue;
      const entry = JSON.parse(localStorage.getItem(key));
      if (entry && typeof entry.id === 'string' && phases.includes(entry.step) && Number.isFinite(Date.parse(entry.at))) result.push({...entry,key});
    }
  } catch { /* The rest of the screen remains readable with storage disabled. */ }
  return result.sort((a,b) => a.at.localeCompare(b.at) || phases.indexOf(a.step) - phases.indexOf(b.step));
}
function showStatus() {
  const count = pending().length;
  const messages = [notice, count ? '送信待ち ' + count + ' 件。通信が戻ると送信します。' : '', !navigator.onLine ? 'オフライン' : ''].filter(Boolean);
  message.textContent = messages.join('　');
  message.hidden = !messages.length;
}
function report(error) {
  if (error.status === 401 || error.status === 403) {
    trips = [];
    main.replaceChildren();
    location.replace('/');
    return;
  }
  notice = error.status ? error.message : '保存先に接続できません。通信を確認してください。';
  showStatus();
}
function mergedSteps(trip, outbox) {
  const steps = [...trip.driverReport.steps];
  for (const entry of outbox) if (entry.id === trip.id && entry.step === phases[steps.length]) steps.push(entry);
  return steps;
}
function stamp(start, end) {
  if (!start) return '時刻未定';
  if (start === '00:00' && end === '11:59') return '午前';
  if (start === '12:00' && end === '23:59') return '午後';
  return start + (end && end !== start ? '〜' + end : '');
}
function stop(place, pref, end, time, endTime, date) {
  const url = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent((pref || '') + place);
  return `<i class="dot ${end ? 'end' : ''}"></i><div class="place">${esc(place)}<small>${esc(pref)}　${end ? '卸し' : '積み'}</small><a class="map" href="${esc(url)}" target="_blank" rel="noopener noreferrer">地図</a></div><div class="time">${esc(stamp(time,endTime))}<small>${esc(day(date))}</small></div>`;
}
function card(trip, current, outbox) {
  const id = esc(trip.id), steps = mergedSteps(trip,outbox), done = steps.length === 4;
  const undo = steps.length && (current || done) ? `<button type="button" class="undo" data-undo="${id}">ひとつ戻す</button>` : '';
  const run = current && !done ? `<button type="button" class="big" data-step="${id}">${actions[steps.length]}</button><div class="row"><button type="button" class="sub" data-photo="${id}">写真をとる</button><button type="button" class="sub" data-memo="${id}">連絡・気づき</button></div>` : '';
  const progress = steps.length || current ? `<div class="steps">${phases.map((_,i) => `<span class="${steps[i] ? 'on' : ''}">${names[i]}<i>${steps[i] ? esc(clock(steps[i].at)) : '　'}</i></span>`).join('')}</div>` : '';
  return `<section class="card ${current ? 'now' : ''} ${done ? 'done' : ''}"><div class="when">${esc(day(trip.date))} ${current ? '<span class="pill">いまの便</span>' : ''}${trip.toll ? '<span class="pill">高速あり</span>' : ''}</div>
    <div class="stops">${stop(trip.from,trip.fromPref,false,trip.st,trip.st2,trip.date)}<i class="rail"></i><div></div><div></div>${stop(trip.to,trip.toPref,true,trip.et,trip.et2,trip.end || trip.date)}</div>
    ${trip.note ? '<div class="note">' + esc(trip.note) + '</div>' : ''}
    <div class="meta">${trip.vehicle ? '車 ' + esc(trip.vehicle) : ''} ${trip.driverReport.hasPhoto ? '写真あり' : ''}</div>
    ${progress}${trip.driverReport.memo ? '<div class="meta">連絡　' + esc(trip.driverReport.memo) + '</div>' : ''}
    ${(run || undo) ? '<div class="act">' + run + (undo || '') + '</div>' : ''}</section>`;
}
function render() {
  const outbox = pending();
  const today = tokyoDay(new Date());
  byId('hs-day').textContent = day(today);
  main.setAttribute('aria-busy', String(!loaded && syncing));
  document.querySelectorAll('[data-tab]').forEach(button => {
    const selected = button.dataset.tab === tab;
    button.classList.toggle('on', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  const sorted = [...trips].sort((a,b) => (a.date + a.st).localeCompare(b.date + b.st));
  const done = t => mergedSteps(t,outbox).length === phases.length;
  const open = sorted.filter(t => !done(t));
  const current = open.find(t => mergedSteps(t,outbox).length) || open.find(t => t.date <= today && (t.end || t.date) >= today);
  let list = [];
  if (tab === 'today') list = [current, ...open.filter(t => t !== current && t.date <= today && (t.end || t.date) >= today)].filter(Boolean);
  if (tab === 'next') list = open.filter(t => t.date > today);
  if (tab === 'done') list = sorted.filter(done).reverse();
  const empty = loaded ? ({today:'きょうの便はありません',next:'これからの便はありません',done:'おわった便はありません'})[tab] : '便を読み込み中…';
  main.innerHTML = list.length ? list.map(t => card(t,t === current,outbox)).join('') : '<div class="empty">' + empty + '</div>';
  showStatus();
}
function replaceTrip(trip) { trips = trips.map(t => t.id === trip.id ? trip : t); }
const endpoint = (id, action) => base + '/trips/' + encodeURIComponent(id) + '/' + action;
async function synchronize() {
  if (syncing) { rerun = true; return; }
  clearTimeout(retryTimer);
  syncing = true;
  try {
    const {user} = await api('/api/me');
    if (user?.id !== account || user?.driverId !== driverId || user?.role !== 'driver') return location.replace('/');
    const result = await api(base + '/trips', {headers:acting});
    trips = result.trips;
    loaded = true;
    notice = '';
    render();
    for (const entry of pending()) {
      if (!localStorage.getItem(entry.key)) continue;
      try {
        const {trip} = await api(endpoint(entry.id,'steps'), {method:'POST', headers:acting, json:{step:entry.step, at:entry.at}});
        replaceTrip(trip);
        localStorage.removeItem(entry.key);
      } catch (error) {
        if (error.status !== 404 && error.status !== 409) throw error;
        // A reassignment, undo, or independent press has superseded this event.
        localStorage.removeItem(entry.key);
        notice = '担当または記録が変更され、送信待ちの操作を反映できませんでした。表示中の便を確認してください。';
      }
    }
    if (notice) trips = (await api(base + '/trips', {headers:acting})).trips;
    retryDelay = 3000;
  } catch (error) {
    report(error);
    // A local server can return while the device remains on the same network
    // (and therefore never receives another 'online' event).
    if (navigator.onLine && pending().length && (!error.status || error.status >= 500)) {
      retryTimer = setTimeout(synchronize, retryDelay);
      retryDelay = Math.min(60000, retryDelay * 2);
    }
  }
  finally {
    syncing = false;
    render();
    if (rerun) { rerun = false; void synchronize(); }
  }
}
async function press(trip) {
  const step = phases[mergedSteps(trip,pending()).length];
  if (!step) return;
  const at = new Date().toISOString();
  try { localStorage.setItem(prefix + crypto.randomUUID(), JSON.stringify({id:trip.id, step, at})); }
  catch {
    try {
      const result = await api(endpoint(trip.id,'steps'), {method:'POST', headers:acting, json:{step,at}});
      replaceTrip(result.trip);
      render();
    } catch (error) { report(error); }
    return;
  }
  render();
  void synchronize();
}
document.addEventListener('click', async event => {
  const button = event.target.closest('button');
  if (!button) return;
  const {tab:next, step, undo, memo, photo} = button.dataset;
  if (next) { tab = next; render(); window.scrollTo(0,0); return; }
  const trip = trips.find(t => t.id === (step || undo || memo || photo));
  if (!trip) return;
  if (step) return press(trip);
  if (memo) {
    memoId = memo;
    byId('hs-memo-form').elements.memo.value = trip.driverReport.memo || '';
    byId('hs-memo').showModal();
  }
  if (photo) { photoId = photo; byId('hs-camera').click(); }
  if (undo) {
    if (pending().some(entry => entry.id === undo)) {
      notice = 'ひとつ戻すには、通信が戻り送信が終わるまでお待ちください。'; showStatus(); return;
    }
    const last = trip.driverReport.steps.at(-1);
    if (!last) return;
    button.disabled = true;
    try {
      const result = await api(endpoint(undo,'steps/last'), {method:'DELETE', headers:acting, json:{step:last.step,at:last.at}});
      replaceTrip(result.trip); render();
    } catch (error) { report(error); button.disabled = false; }
  }
});
byId('hs-cancel').onclick = () => byId('hs-memo').close();
byId('hs-memo-form').onsubmit = async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const submit = form.querySelector('.big');
  if (submit.disabled) return;
  submit.disabled = true;
  try {
    const result = await api(endpoint(memoId,'memo'), {method:'POST', headers:acting, json:{memo:form.elements.memo.value}});
    replaceTrip(result.trip); byId('hs-memo').close(); notice = '連絡を保存しました。'; render();
  } catch (error) { report(error); if (byId('hs-memo').open) window.alert(notice); }
  finally { submit.disabled = false; }
};
byId('hs-camera').onchange = async event => {
  const file = event.target.files?.[0];
  event.target.value = '';
  if (!file || !photoId) return;
  if (file.size > 2 * 1024 * 1024 || !['image/png','image/jpeg','image/webp'].includes(file.type)) {
    notice = '2 MB 以下の JPEG・PNG・WebP 画像を選んでください。'; showStatus(); return;
  }
  try {
    const result = await api(endpoint(photoId,'photos'), {method:'POST', body:file,
      headers:{...acting, 'Content-Type':file.type, 'Idempotency-Key':crypto.randomUUID()}});
    replaceTrip(result.trip); notice = '写真を保存しました。'; render();
  } catch (error) { report(error); }
};
window.addEventListener('online', synchronize);
window.addEventListener('offline', showStatus);
window.addEventListener('storage', event => { if (event.key?.startsWith(prefix)) render(); });
document.addEventListener('visibilitychange', () => { if (!document.hidden) void synchronize(); });
void synchronize();
