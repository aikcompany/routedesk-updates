import {api} from './shell.js';

const recovery = document.getElementById('hs-recover-password');
let recoveryCode;
if (location.pathname === '/recover' && location.search) {
  if (recovery) recoveryCode = new URLSearchParams(location.search).get('code');
  history.replaceState(null, '', '/recover');
}

const passwordForm = recovery || document.getElementById('hs-change-password');
if (passwordForm) mountForm(passwordForm);

function mountForm(form) {
  const {newPassword, confirmPassword} = form.elements;
  const notice = document.getElementById('hs-message');
  const submit = form.querySelector('button[type=submit]');
  const reveal = document.getElementById('hs-show-passwords');
  const fields = [...form.querySelectorAll('input[type=password]')];

  function checkConfirmation() {
    newPassword.setCustomValidity(newPassword.value && [...newPassword.value].length < 10
      ? '新しいパスワードは10文字以上で入力してください。' : '');
    confirmPassword.setCustomValidity(confirmPassword.value && confirmPassword.value !== newPassword.value
      ? '確認用のパスワードが一致しません。' : '');
  }
  newPassword.addEventListener('input', checkConfirmation);
  confirmPassword.addEventListener('input', checkConfirmation);
  reveal.addEventListener('change', () => {
    for (const field of fields) field.type = reveal.checked ? 'text' : 'password';
  });

  form.addEventListener('submit', async event => {
    event.preventDefault();
    checkConfirmation();
    if (!form.reportValidity() || submit.disabled) return;
    submit.disabled = true;
    notice.textContent = '';
    try {
      if (recovery) {
        await api('/api/recover', {method:'POST', json:{code:recoveryCode, userId:form.elements.userId.value, newPassword:newPassword.value}});
      } else {
        await api('/api/me/password', {method:'POST', json:{currentPassword:form.elements.currentPassword.value, newPassword:newPassword.value}});
      }
      form.reset();
      if (recovery) {
        recoveryCode = undefined;
        form.hidden = true;
        const title = document.querySelector('main h1');
        title.textContent = 'パスワードを決め直しました';
        const back = document.querySelector('.hs-form-foot a');
        back.textContent = 'ルートデスクを開く';
        back.focus();
      } else location.replace('/');
    } catch (error) {
      notice.textContent = error.status ? error.message : '接続できません。通信を確認してください。';
      submit.disabled = false;
    }
  });
}
