const printButton = document.querySelector('[data-print-invoice]');
const statusMessage = document.createElement('span');
statusMessage.setAttribute('role', 'status');
printButton.before(statusMessage, ' ');

const methodLabels = {print:'印刷', fax:'FAX送信', email:'メール送信', pdf:'PDF保存'};
const when = new Intl.DateTimeFormat('ja-JP', {dateStyle:'short', timeStyle:'short', timeZone:'Asia/Tokyo'});
let pending = [];

function operationId() {
  if (crypto.randomUUID) return crypto.randomUUID();
  // LAN 上の HTTP でも使える乱数から UUID v4 を作る。
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  const hex = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
  return [hex.slice(0, 8), hex.slice(8, 12), hex.slice(12, 16), hex.slice(16, 20), hex.slice(20)].join('-');
}

async function post(path, body, actorId) {
  const headers = {'Content-Type':'application/json'};
  if (actorId) headers['X-Acting-User'] = encodeURIComponent(actorId);
  const response = await fetch(path, {method:'POST', headers,
    credentials:'same-origin', body:JSON.stringify(body)});
  const data = await response.json();
  if (!response.ok) {
    throw Object.assign(new Error(data.error || '通信に失敗しました。'), {status:response.status, output:data.output});
  }
  return data;
}

function previousOutput(output) {
  return output.actorName + 'さんが ' + when.format(new Date(output.at)) + ' に' +
    (methodLabels[output.method] || output.method) + '済みです。';
}

function openPrintDialog() {
  return new Promise((resolve, reject) => {
    // print() が先に戻るブラウザーでも、確認は印刷画面が閉じた後に行う。
    const closed = () => window.setTimeout(resolve, 0);
    window.addEventListener('afterprint', closed, {once:true});
    try { window.print(); }
    catch (error) {
      window.removeEventListener('afterprint', closed);
      reject(error);
    }
  });
}

async function printInvoices() {
  const jobs = [];
  let actorId;
  for (const {kind, month, customerId, version, customer} of JSON.parse(printButton.dataset.outputDocuments)) {
    const key = {kind, month, customerId, version};
    const label = (customer || customerId) + '（' + (kind === 'invoice-draft' ? '下書き' : '第' + version + '版') + '）';
    const check = await post('/api/outputs/check', key, actorId);
    if (!check.actorId || (actorId && actorId !== check.actorId)) {
      throw new Error('担当者を確認できません。印刷する方でログインし直してください。');
    }
    actorId = check.actorId;
    const existing = check.outputs[0];
    if (existing && !window.confirm(label + '\n' + previousOutput(existing) + '\nもう一度印刷しますか？')) {
      statusMessage.textContent = '印刷を取りやめました。';
      return;
    }
    jobs.push({label, actorId, body:{...key, method:'print', result:'done', operationId:operationId(),
      ...(existing ? {} : {expectNone:true})}});
  }
  if (!jobs.length) throw new Error('印刷する請求書が見つかりません。');
  await openPrintDialog();
  // ページ範囲の指定やキャンセルをブラウザーから判別できないので、取引先ごとに確認する。
  pending = jobs.filter(job => window.confirm(job.label +
    '\nこの請求書は紙に刷れましたか？\n刷れた場合は「OK」、中止・PDF保存の場合は「キャンセル」を押してください。'));
  if (!pending.length) statusMessage.textContent = '今回は印刷済みの記録を追加していません。';
}

async function recordPrint({body, label, actorId}) {
  try {
    await post('/api/outputs', body, actorId);
  } catch (error) {
    if (error.status !== 409 || !error.output || !body.expectNone) throw error;
    const add = window.confirm(label + '\n印刷の確認中に別の記録が入りました。\n' +
      previousOutput(error.output) + '\n今回刷れた分も記録しますか？');
    if (!add) return false;
    delete body.expectNone;
    await post('/api/outputs', body, actorId);
  }
  return true;
}

async function recordConfirmedPrints() {
  const retry = [];
  const failures = [];
  let saved = 0;
  let skipped = 0;
  for (const job of pending) {
    try {
      if (await recordPrint(job)) saved++;
      else skipped++;
    } catch (error) {
      retry.push(job);
      failures.push(job.label + ' ' + error.message);
    }
  }
  pending = retry;
  statusMessage.textContent = '印刷済みの記録を' + saved + '件保存しました。' +
    (skipped ? ' 記録の追加を' + skipped + '件見送りました。' : '');
  if (failures.length) {
    statusMessage.textContent += ' 次の記録を確認できません。印刷記録を再試行してください。 ' + failures.join(' ／ ');
  }
}

async function handlePrint() {
  if (printButton.disabled) return;
  printButton.disabled = true;
  statusMessage.textContent = '';
  try {
    if (!pending.length) await printInvoices();
    if (pending.length) await recordConfirmedPrints();
  } catch (error) {
    statusMessage.textContent = '印刷を進められませんでした。' + error.message;
  } finally {
    printButton.textContent = pending.length ? '印刷記録を再試行' : '印刷';
    printButton.disabled = false;
  }
}

printButton.addEventListener('click', handlePrint);
if (new URLSearchParams(location.search).get('print') === '1') {
  window.addEventListener('load', handlePrint, {once:true});
}
