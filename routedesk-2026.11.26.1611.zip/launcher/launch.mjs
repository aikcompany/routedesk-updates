// 「ルートデスク」を PC のアプリとして開く入口（黒い窓を出さない）。
//   （引数なし）   裏で動いていなければ起こし、専用の窓で開く。最初の 1 回はデスクトップのアイコンと自動起動を登録する。
//   --background  裏で起こすだけ（PC を起動したとき用）。
//   --stop        裏で動いているものを止める。
//   --uninstall   アイコンと自動起動の登録を消して止める（データは消さない）。
//   --recover     管理者のパスワードを決め直す画面を開く（この PC の中だけで使える 10 分かぎりの案内）。
// 確かめ用: --port <番号> --shortcut-dir <場所> --startup-dir <場所> --no-window --no-install --task <予定の名前>
import fs from 'node:fs';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const argv = process.argv.slice(2);
const flag = (name) => argv.includes(name);
const value = (name) => { const i = argv.indexOf(name); return i >= 0 ? argv[i + 1] : undefined; };
const port = value('--port') ?? '4310';
const url = `http://127.0.0.1:${port}/`, home = url;
const appDir = value('--app-dir') ?? path.join(root, 'app');
const dataDir = value('--data-dir') ?? path.join(root, 'data');
const stateFile = path.join(dataDir, 'launcher.json');
const logFile = path.join(dataDir, 'launcher.log');
const NAME = 'ルートデスク';

const log = (text) => { try { fs.mkdirSync(dataDir, { recursive: true }); fs.appendFileSync(logFile, new Date().toISOString() + ' ' + text + '\n'); } catch {} };
const readState = () => { try { return JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch { return {}; } };
const writeState = (patch) => { fs.mkdirSync(dataDir, { recursive: true }); fs.writeFileSync(stateFile, JSON.stringify({ ...readState(), ...patch }, null, 1)); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const alive = async () => { try { const r = await fetch(url + 'api/health', { signal: AbortSignal.timeout(1500) }); return r.ok; } catch { return false; } };
const waitAlive = async (want, tries = 60) => { for (let i = 0; i < tries; i++) { if ((await alive()) === want) return true; await sleep(250); } return false; };

// PowerShell に日本語をそのまま渡す（ファイルを作らないので、実行の決まりに触れない）
const ps = (script) => spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')], { encoding: 'utf8', windowsHide: true });
const q = (text) => "'" + String(text).replaceAll("'", "''") + "'";
const say = (text) => ps(`Add-Type -AssemblyName System.Windows.Forms; [void][System.Windows.Forms.MessageBox]::Show(${q(text)}, ${q(NAME)})`);

async function ensureServer() {
  if (await alive()) return true;
  const task = value('--task');
  if (task) spawnSync('schtasks.exe', ['/run', '/tn', task], { windowsHide: true });
  else {
    const args = [path.join(appDir, 'bin', 'start.mjs'), '--data', dataDir, '--port', port,
      '--ui', path.join(root, 'ui', '配車ボード.html'), '--driver-ui', path.join(root, 'ui', '運転手.html')];
    // 新しい版を見に行く先（置き場と公開鍵）。update.json が無い配り方では、何も見に行かない。
    try { const u = JSON.parse(fs.readFileSync(path.join(root, 'update.json'), 'utf8'));
      if (typeof u.manifest === 'string' && typeof u.key === 'string') args.push('--update-manifest', u.manifest, '--update-key', u.key); } catch {}
    fs.mkdirSync(dataDir, { recursive: true });
    const out = fs.openSync(path.join(dataDir, 'server.log'), 'a');
    const child = spawn(process.execPath, args, { cwd: root, detached: true, windowsHide: true, stdio: ['ignore', out, out] });
    child.unref();
    writeState({ pid: child.pid, startedAt: new Date().toISOString() });
    log('起こした pid ' + child.pid);
  }
  return waitAlive(true);
}

function findBrowser() {
  const env = process.env, tails = [['Microsoft', 'Edge', 'Application', 'msedge.exe'], ['Google', 'Chrome', 'Application', 'chrome.exe']];
  for (const tail of tails) for (const base of [env['ProgramFiles(x86)'], env.ProgramFiles, env.LOCALAPPDATA]) {
    if (!base) continue;
    const file = path.join(base, ...tail);
    if (fs.existsSync(file)) return file;
  }
  return null;
}

function openWindow(url = home) {
  const browser = findBrowser();
  // 専用の窓（タブも住所の欄も出ない）。無ければいつものブラウザーで開く。
  // 窓の大きさと場所は、ブラウザーが前回のものを覚えている。大きさを指定するのは最初の 1 回だけ（毎回指定すると、前回の大きさに戻らない）。
  const first = !readState().windowOpened; if (first) { try { writeState({ windowOpened: true }); } catch {} }
  const child = browser ? spawn(browser, ['--app=' + url, ...(first ? ['--window-size=1500,950'] : [])], { detached: true, stdio: 'ignore' })
    : spawn('cmd.exe', ['/c', 'start', '', url], { detached: true, stdio: 'ignore', windowsHide: true });
  child.unref();
  log('窓を開いた ' + (browser ? path.basename(browser) : 'いつものブラウザー'));
}

function shortcutDirs() {
  const custom = { desktop: value('--shortcut-dir'), startup: value('--startup-dir') };
  if (custom.desktop && custom.startup) return custom;
  const r = ps("[Console]::OutputEncoding=[Text.Encoding]::UTF8; [Environment]::GetFolderPath('Desktop'); [Environment]::GetFolderPath('Startup')");
  const [desktop, startup] = String(r.stdout).split(/\r?\n/u).map((s) => s.trim()).filter(Boolean);
  return { desktop: custom.desktop ?? desktop, startup: custom.startup ?? startup };
}

function install() {
  const dirs = shortcutDirs();
  if (!dirs.desktop || !dirs.startup) { log('アイコンを置く場所が分からない'); return false; }
  const wscript = path.join(process.env.SystemRoot ?? 'C:/Windows', 'System32', 'wscript.exe');
  const vbs = path.join(root, NAME + '.vbs'), icon = path.join(here, 'haishashitsu.ico');
  const extra = [value('--port') ? '--port ' + port : '', value('--task') ? '--task ' + value('--task') : ''].filter(Boolean).join(' ');
  const make = (file, args, note) => `$s=$w.CreateShortcut(${q(file)}); $s.TargetPath=${q(wscript)}; $s.Arguments=${q('"' + vbs + '"' + (args ? ' ' + args : ''))}; $s.WorkingDirectory=${q(root)}; $s.IconLocation=${q(icon)}; $s.Description=${q(note)}; $s.Save();`;
  const desk = path.join(dirs.desktop, NAME + '.lnk'), boot = path.join(dirs.startup, NAME + '.lnk');
  const lines = ['$w=New-Object -ComObject WScript.Shell;', make(desk, extra, 'ルートデスクを開く')];
  // 予定（--task）で起こしている PC では、自動起動は予定に任せる
  if (!value('--task')) lines.push(make(boot, ('--background ' + extra).trim(), 'ルートデスクを裏で起こす'));
  const r = ps(lines.join(' '));
  const ok = r.status === 0 && fs.existsSync(desk);
  if (ok) writeState({ installed: true, desktop: desk, startup: value('--task') ? null : boot, root });
  log('アイコンの登録 ' + (ok ? '済' : '失敗 ' + String(r.stderr).slice(0, 200)));
  return ok;
}

async function stop() {
  const state = readState();
  if (!(await alive())) { log('止める: 動いていない'); return true; }
  if (!state.pid) { log('止める: 番号が分からない'); return false; }
  try { process.kill(state.pid); } catch (e) { log('止める: ' + e.message); }
  const down = await waitAlive(false, 40);
  if (down) writeState({ pid: null });
  log('止めた ' + down);
  return down;
}

// 管理者がパスワードを忘れたとき。案内のアドレスは 1 回かぎりなので、記録にも状態にも残さない。
async function recover() {
  if (!(await ensureServer())) { say('ルートデスクを起こせませんでした。'); return 1; }
  const r = spawnSync(process.execPath, [path.join(appDir, 'bin', 'recover-admin.mjs'), '--data', dataDir, '--company', value('--company') ?? 'local'], { encoding: 'utf8', windowsHide: true });
  let target = null; try { target = JSON.parse(String(r.stdout).trim().split('\n').pop().trim()).path; } catch {}
  if (r.status !== 0 || typeof target !== 'string' || !target.startsWith('/')) { log('決め直しの案内を出せなかった'); say('決め直しの画面を開けませんでした。もう一度お試しください。'); return 1; }
  openWindow(url.slice(0, -1) + target); log('決め直しの画面を開いた');
  return 0;
}

// ---- 新しい版への入れ替え
// アプリが受け取って確かめ終えた物（<data>.updates/<版>/ready.json と zip）があれば、開くときに入れ替える。
// 順番: 中身を確かめる → 止める → 控え → 入れ替え → 起こす。起きなければ前の版に戻す。データ（data）は動かさない。
const versionOf = (dir) => { try { return String(JSON.parse(fs.readFileSync(path.join(dir, 'version.json'), 'utf8')).version); } catch { return '0.0.0.0'; } };
const versionParts = (v) => (/^\d{1,4}(\.\d{1,4}){3}$/u.test(v) ? v.split('.').map(Number) : null);
const newer = (a, b) => { const x = versionParts(a), y = versionParts(b) ?? [0, 0, 0, 0]; if (!x) return false; for (let i = 0; i < 4; i++) if (x[i] !== y[i]) return x[i] > y[i]; return false; };
const UI_NAMES = [['board.html', '配車ボード.html'], ['driver.html', '運転手.html']];

async function sha256File(file) {
  const { createHash } = await import('node:crypto'); const hash = createHash('sha256');
  for await (const chunk of fs.createReadStream(file)) hash.update(chunk);
  return hash.digest('hex');
}

async function applyUpdate() {
  // 予定や別の場所のアプリで動かしている PC（開発用）では、ここでは入れ替えない
  if (value('--task') || value('--app-dir') || flag('--no-update')) return false;
  const box = dataDir + '.updates', current = versionOf(root);
  let ready = null, dir = null;
  try { for (const name of fs.readdirSync(box)) {
    const file = path.join(box, name, 'ready.json'); if (!fs.existsSync(file)) continue;
    const r = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (r.version === name && newer(r.version, ready?.version ?? current) && /^[A-Za-z0-9._-]{1,80}\.zip$/u.test(r.file ?? '') && /^[0-9a-f]{64}$/u.test(r.sha256 ?? '')) { ready = r; dir = path.join(box, name); }
  } } catch { return false; }
  if (!ready) return false;
  const giveUp = (why) => { log('入れ替えをやめた（' + ready.version + '）: ' + why); try { fs.renameSync(path.join(dir, 'ready.json'), path.join(dir, 'failed.json')); } catch {} return false; };
  const zip = path.join(dir, ready.file), next = path.join(root, 'update.next'), prev = path.join(root, 'update.prev');
  if (!fs.existsSync(zip) || (await sha256File(zip)) !== ready.sha256) return giveUp('受け取った物が合わない');
  fs.rmSync(next, { recursive: true, force: true }); fs.mkdirSync(next, { recursive: true });
  const tar = path.join(process.env.SystemRoot ?? 'C:/Windows', 'System32', 'tar.exe');
  const un = spawnSync(tar, ['-x', '-f', zip, '-C', next], { windowsHide: true, encoding: 'utf8' });
  const whole = un.status === 0 && fs.existsSync(path.join(next, 'app', 'bin', 'start.mjs')) && UI_NAMES.every(([a]) => fs.existsSync(path.join(next, 'ui', a))) && versionOf(next) === ready.version;
  if (!whole) { fs.rmSync(next, { recursive: true, force: true }); return giveUp('中身がそろっていない'); }
  if ((await alive()) && !(await stop())) { fs.rmSync(next, { recursive: true, force: true }); log('入れ替えは次の回に（止められなかった）'); return false; }
  const backup = spawnSync(process.execPath, [path.join(appDir, 'bin', 'backup.mjs'), '--data', dataDir], { windowsHide: true, encoding: 'utf8' });
  if (fs.existsSync(path.join(dataDir, 'local')) && backup.status !== 0) { fs.rmSync(next, { recursive: true, force: true }); log('入れ替えは次の回に（控えを取れなかった）'); return false; }
  const moveIn = (from) => {
    fs.renameSync(path.join(from, 'app'), path.join(root, 'app')); fs.mkdirSync(path.join(root, 'ui'), { recursive: true });
    for (const [a, b] of UI_NAMES) fs.renameSync(path.join(from, 'ui', from === next ? a : b), path.join(root, 'ui', b));
    if (fs.existsSync(path.join(from, 'version.json'))) fs.copyFileSync(path.join(from, 'version.json'), path.join(root, 'version.json')); else fs.rmSync(path.join(root, 'version.json'), { force: true });
  };
  const moveOut = (to) => {
    fs.rmSync(to, { recursive: true, force: true }); fs.mkdirSync(path.join(to, 'ui'), { recursive: true });
    fs.renameSync(path.join(root, 'app'), path.join(to, 'app'));
    for (const [, b] of UI_NAMES) if (fs.existsSync(path.join(root, 'ui', b))) fs.renameSync(path.join(root, 'ui', b), path.join(to, 'ui', b));
    if (fs.existsSync(path.join(root, 'version.json'))) fs.copyFileSync(path.join(root, 'version.json'), path.join(to, 'version.json'));
  };
  try { moveOut(prev); moveIn(next); }
  catch (e) { log('入れ替えの途中で失敗: ' + e.message); try { if (!fs.existsSync(path.join(root, 'app'))) moveIn(prev); } catch {} return giveUp('入れ替えられなかった'); }
  if (await ensureServer()) {
    for (const f of ['launch.mjs', 'haishashitsu.ico']) try { fs.copyFileSync(path.join(next, 'launcher', f), path.join(here, f)); } catch {}
    fs.rmSync(next, { recursive: true, force: true }); fs.rmSync(dir, { recursive: true, force: true });
    writeState({ updatedTo: ready.version, updatedAt: new Date().toISOString(), updatedFrom: current });
    log('新しい版に入れ替えた ' + current + ' → ' + ready.version);
    return true;
  }
  // 起きなかった → 前の版に戻す
  await stop(); const bad = path.join(root, 'update.bad');
  try { moveOut(bad); moveIn(prev); } catch (e) { log('戻せなかった: ' + e.message); }
  fs.rmSync(next, { recursive: true, force: true }); fs.rmSync(bad, { recursive: true, force: true });
  giveUp('新しい版が起きなかったので、前の版に戻した');
  if (!flag('--no-window') && !flag('--background')) say('新しい版を入れられなかったので、前の版に戻しました。そのまま使えます。');
  return false;
}

async function main() {
  if (flag('--recover')) return recover();
  if (flag('--stop')) { const ok = await stop(); if (!flag('--no-window')) say(ok ? 'ルートデスクを止めました。' : '止められませんでした。PC を再起動してください。'); return ok ? 0 : 1; }
  if (flag('--uninstall')) {
    const state = readState();
    await stop();
    for (const file of [state.desktop, state.startup]) if (file) fs.rmSync(file, { force: true });
    writeState({ installed: false, desktop: null, startup: null });
    if (!flag('--no-window')) say('アイコンと自動起動の登録を消しました。データ（data フォルダー）は残っています。');
    return 0;
  }
  // フォルダーを別の場所へ動かしたあとは、アイコンを作り直す
  const state = readState();
  if (!flag('--no-install') && !flag('--background') && (!state.installed || state.root !== root || (state.desktop && !fs.existsSync(state.desktop)))) install();
  try { await applyUpdate(); } catch (e) { log('入れ替えの確かめで失敗 ' + (e?.message ?? e)); }
  const up = await ensureServer();
  if (!up) { log('起きなかった'); if (!flag('--background') && !flag('--no-window')) say('ルートデスクを起こせませんでした。data フォルダーの server.log を確かめてください。'); return 1; }
  if (!flag('--background') && !flag('--no-window')) openWindow();
  return 0;
}

main().then((code) => { process.exitCode = code; }, (e) => { log('失敗 ' + (e?.stack ?? e)); process.exitCode = 1; });
