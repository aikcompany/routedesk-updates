const cacheName = 'haishashitsu-shell-v5';
const files = new Set([
  '/manifest.webmanifest', '/assets/icon-192.png', '/assets/icon-512.png',
  '/assets/shell.css', '/assets/shell.js', '/assets/admin.js', '/assets/driver.js',
  '/assets/masters.js', '/assets/setup.js', '/assets/password.js',
  '/assets/invoices.js', '/assets/invoices.css', '/assets/invoice-settings.js',
]);

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(cacheName);
    await cache.addAll([...files]);
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('haishashitsu-shell-') && key !== cacheName).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const {request} = event;
  if (request.method !== 'GET' || request.mode === 'navigate') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin || url.search || !files.has(url.pathname)) return;
  event.respondWith((async () => {
    const cache = await caches.open(cacheName);
    // Network-first keeps an already-installed app compatible with API updates.
    try {
      const response = await fetch(request);
      if (response.ok && !response.redirected && response.type === 'basic') await cache.put(request, response.clone());
      return response;
    } catch (error) {
      const stored = await cache.match(request);
      if (stored) return stored;
      throw error;
    }
  })());
});
