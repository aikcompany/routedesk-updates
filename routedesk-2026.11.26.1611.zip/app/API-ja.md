# ルートデスクの画面と保存API

既定は `http://127.0.0.1:4310`。1つのサーバーが起動時に選んだ1社のSQLiteを扱います。日付は `YYYY-MM-DD`、時刻は24時間表記の `HH:mm`、金額は円です。リクエストは同一オリジンへ送り、JSONの本文には `Content-Type: application/json` を指定します。通常の正常応答は200、エラーはJSONの `error` に日本語の理由が入ります。

## ログインと権限

| 利用者 | 画面と取得できる項目 | 書き込み |
|---|---|---|
| 未ログイン | 利用者が0人の保存先では、このPCの `/` に「最初の設定」。登録後はログイン画面。ヘルスチェックと公開された画面部品 | 初回設定、ログイン、このPCで発行した有効な案内による管理者の復旧 |
| 運転手 `driver` | 本人のアカウント、担当便の車・積卸地・日付・時刻・高速の有無・本人用の作業記録 | 本人のパスワード変更、自分の便の進行、直前の進行の取り消し、連絡、写真 |
| 配車係 `dispatcher` | 全便と事務情報（運賃・取引先・事務メモ）、予定・運転手・車・候補・差分・CSV、運転手の連絡先、各便の運転手の記録、請求一覧・紙面・過去の版、届いた依頼と添付 | 本人のパスワード変更、便・予定の編集、候補の計数、成約取込、請求書の発行、届いた依頼の便登録・見送り・再開 |
| 管理者 `admin` | 配車係の全項目、利用者・運転手・車・取引先・会社の登録内容、期限の知らせ、資料から読み取った案、成約取り込み状況 | 配車係の全操作、利用者の発行・停止・再発行、登録内容・会社・取り込みの設定、資料からの案の採否 |

| メソッド・パス | 要求と応答 |
|---|---|
| `POST /api/setup` | 初回専用。本文 `{companyName,id,password,confirmPassword,garage}`。成功時は **201**、`{user}` と管理者のセッション Cookie |
| `POST /api/login` | 本文 `{id,password}`。成功時 `{user}` とセッション Cookie。ID またはパスワード違い・停止中は401 |
| `GET /api/me` | `{user}`。未ログイン・失効後は401。仮パスワードを決め直す前は403 |
| `POST /api/logout` | 本文不要。`{ok:true}`。サーバーで現在のセッションを無効化し Cookie を消去 |

`user` の公開項目は `{id,displayName,role,driverId,disabled,mustChangePassword?}`。運転手の `driverId` は `GET /api/admin/drivers` の各行の固定 `id` です。改名後も同じ値で、ほかの役目では null です。Cookie は `HttpOnly; SameSite=Lax; Path=/` で、最後の利用から30日有効です。HTTPS 用の `Secure` 切替は起動設定にあります。画面からは同一オリジンの通常の fetch を使います。

初回画面では会社名・管理者のログインID・パスワード2回・車庫の市区町村を入力します。会社名と車庫は各256文字まで、IDは128文字まで、パスワードは10〜1024文字です。車庫は全国の候補から選ぶか直接入力します。「始める」で会社設定・管理者・セッションを一緒に保存し、`/` を開くとボードが表示されます。入力誤りは400、外部接続や別オリジンからの要求は403です。既存の利用者がいる場合、または同時送信で先に別の設定が成功した場合は409です。

連続失敗は15分の集計期間で、同じIDが5回、または同じ接続元が20回に達すると60秒待機します。待機応答は429で `Retry-After` に残り秒数が入ります。役目の違うAPIには403を返します。配車ボードの初期読込や同期中に401になった場合は、`/` を開き直してログイン画面へ戻ります。

## パスワードの変更と管理者の復旧

管理者による利用者発行・再発行と、運転手登録に伴うログイン発行では、応答の `user.mustChangePassword` が `true` になります。ログイン成功時の `{user}` でも同じ印を確認できます。印があれば `/password`、通常は `/` に進みます。印の省略は変更不要を表します。旧版の会社データと最初の設定で登録した管理者は変更不要から始まります。

| メソッド・パス | 要求と応答 |
|---|---|
| `GET /password` | 全役目共通の本人用フォーム。未ログインは401。初回変更が必要なら `/` や `/admin` を開いてもこのフォームを返し、業務APIは403を返します。ログアウトは利用できます |
| `POST /api/me/password` | ログイン中の本人が `{currentPassword,newPassword}` を送信。成功は200で `{user,redirect:"/"}`。初回の印が外れ、現在のセッションは継続し、同じ利用者のほかのセッションは失効します |
| `GET /recover?code=…` | このPCで発行した案内を開くと、有効な管理者のIDを選ぶHTMLを返します。未登録の会社では初回設定を、既存の会社に有効な管理者がいないときは控えからの復元を案内します |
| `POST /api/recover` | ログイン不要。`{code,userId,newPassword}` を送信し、成功時は200で `{ok:true}`。選んだ管理者の初回の印を外し、全セッションを失効させます。復旧後は新しいパスワードでログインします |

新しいパスワードは10〜1024文字です。画面側で2回の入力を照合し、本人が入力内容の表示を切り替えられます。本人用の変更では現在と同じものを指定すると400、今のパスワードが違うと403です。ログインと変更はID・接続元の試行制限を共有し、待機時には429と `Retry-After` を返します。

復旧はソケットの接続元がこのPCのループバックである場合に限ります。合い言葉は10分間有効で、新規発行すると前の案内は失効します。誤り・期限切れ・使用済みの応答は一律403で、GETは案内画面、POSTは同じ理由の `{error}` です。誤りが5回続くと発行分を失効させます。有効な案内で対象外のIDや長さの合わないパスワードを送った場合は400で、期限内なら訂正できます。監査の成功記録は `password.change` と `password.recover` です。

### PCの起動入口との接続

起動入口から同梱のNodeで `app/bin/recover-admin.mjs --data <起動中のデータの親> --company <会社の印>` を実行します。成功時の標準出力は `{"path":"/recover?code=…"}` の1行です。終了コード0を確認してJSONを読み、返った相対パスを、対象会社を起動したローカルアドレスとポートに付けて窓を開きます。戻り値はメモリー内で引き渡してください。CLIは会社のSQLiteを開かず、稼働中のアプリが同じ会社フォルダーの `recover.json` にあるハッシュと期限で照合します。

## 運転手の便

`GET /api/my/trips` はログイン中の運転手の担当便を `{trips:[…]}` で返します。未定便は含まれません。便IDはこのAPI専用で、URLには返された `id` をそのまま `encodeURIComponent` して使います。配車ボードのIDとは別で、担当が変わると前の運転手のIDは使えなくなります。ほかの人の便と存在しない便はどちらも404です。

| 便の全公開項目 | 意味 |
|---|---|
| `id, driver, vehicle` | 本人用の便ID、担当、車 |
| `date, end, from, fromPref, to, toPref` | 積む日・卸す日と各地点・都道府県 |
| `st, st2, et, et2, stWindowEndDate, etWindowEndDate` | 積卸の時刻、時間幅の終端と日またぎの日付。未入力は空文字 |
| `toll, note` | 高速の有無と、「午前」「9時半」など時刻と確認できた出面の記述。日付だけ・金額・自由文は除外 |
| `driverReport` | `{steps:[{step,at}],memo,hasPhoto}`。初期値は `{steps:[],memo:"",hasPhoto:false}` |

運賃、事務メモ、取引先欄（担当者名を含む場合があります）、元の「時間」欄、成約ID、元データの追加項目は送信しません。写真のバイナリ、ファイル名、保存パスも応答に入りません。

以下の操作は `/api/my/trips/:id` に続けます。成功時はいずれも `{trip: 更新後の本人用の便}` です。ログイン切替が起こり得る画面は、本人確認した `encodeURIComponent(user.id)` を `X-Acting-User` ヘッダーで送れます。現在の利用者と異なる場合は403です。

| 操作 | 本文と動作 |
|---|---|
| `POST …/steps` | 例 `{"step":"start","at":"2026-11-25T08:30:00+09:00"}`。出発 `start` → 積み終わり `load` → 卸し地到着 `arrive` → 完了 `done`。順序違い・前の記録より早い時刻は409。同じステップと時刻の再送は重複記録しません |
| `DELETE …/steps/last` | 本文なしで直前を取り消します。画面では表示中の `{step,at}` を送ると、その後に別の操作があった場合に409で止まります |
| `POST …/memo` | `{"memo":"受付済み"}`。4000文字まで、空文字で消去。事務メモとは別欄 |
| `POST …/photos` | JPEG・PNG・WebP のバイト列を対応する `Content-Type` で直接送信。上限2,097,152バイト。形式不一致は415、容量超過は413。`Idempotency-Key: <UUID>` を付け、再送時も同じキーと画像を送ると1枚として記録します |

`at` は秒・タイムゾーン付きのISO日時、またはUnixミリ秒を受け付け、UTCのISO文字列で返します。運転手の操作も会社の版を進めます。配車係・管理者には `state.trips[].driverReport` と `changes[].after.driverReport` で同じ内容が届きます。作業前のA1便では `driverReport` が省略されるので空の初期値を使用します。配車ボードの `memo` は従来どおり事務メモです。

## 管理者の利用者・設定

管理者はボードの「設定」から操作できます。

| メソッド・パス | 要求と応答 |
|---|---|
| `GET /api/admin/users` | `{users:[user,…]}` |
| `POST /api/admin/users` | 発行例 `{"action":"create","id":"sample-driver","displayName":"運転担当A","role":"driver","driverId":"担当A"}`。`driverId` に使用中の運転手マスターから取得した固定IDを指定。他の役目では省略 |
| 同上 | `{"action":"reset","id":"sample-driver"}` で再発行。`create` と `reset` の成功応答は `{user,temporaryPassword}`。仮パスワードを確認できるのはこの応答だけです |
| 同上 | `{"action":"disable","id":"sample-driver"}` で停止し `{user}` を返します。再発行・停止時はそのアカウントの全セッションが失効します。最後の有効な管理者の停止は409 |
| `GET /api/admin/settings` | `{settings:{companyName?,garage?,issuer,invoiceRules,documentFolder,requestInbox,candidateCosts,import:{agreements:{enabled,sourceDir}}}}`。旧フォルダー取り込みの既定は `{"enabled":false,"sourceDir":""}` |
| `POST /api/admin/settings` | 指定した項目を更新し `{settings}` を返します。例 `{"garage":"小牧市"}`。取り込みを設定する場合は `{"import":{"agreements":{"enabled":true,"sourceDir":"D:/sample/agreements"}}}` のように両項目を指定します。自動取り込みを初めて設定する前の会社設定だけの更新応答では `import` を省略する場合があります |
| `GET /api/admin/status` | `{agreements,requestInbox}`。成約の `agreements:{lastAttemptAt,lastSuccessAt,lastAdded,error}` は各値が null から始まります。成功時は追加件数と日時、失敗時は最終試行日時と日本語の理由を更新します。依頼の状態は「届いた依頼」を参照してください |

管理者が自分自身に `reset` または `disable` を送ると409を返し、既存のログインを維持します。応答の `error` は「自分のパスワードは『自分のパスワード』から変えてください。」です。本人の変更には `POST /api/me/password` を使います。

### 運転手と車・取引先

詳細の一覧・登録・修正・統合は管理者用です。新規は `id` を省略します。名前が未定でも、車番や住所など分かっている情報が1つあれば仮登録できます。管理者の一覧には固定 `id` とともに表示され、あとからそのIDに名前を追加できます。名前を入れるまではボード・連絡先・配車・ログインの対象外です。期限を入れた運転手・車の仮登録は期限の知らせで確認できます。配車に使う登録済みの名前を消すことはできません。

修正は取得済みの固定 `id` と変更項目を送ります。省略した項目は保存済みの値を引き継ぎます。同名の登録は409、存在しないIDは404、未対応の項目・入力値は400です。

| メソッド・パス | 本文・応答 |
|---|---|
| `GET /api/admin/drivers` | `{drivers:[運転手と車の登録行,…]}`。休み・使用停止を含みます |
| `GET /api/admin/drivers?view=contacts` | 管理者と配車係が使う連絡先。`{drivers:[{id,name,tel,email},…]}`。運転手のログインからは403 |
| `POST /api/admin/drivers` | 新規例 `{"name":"担当A","vehicle":"車01","plate":"テスト01","tons":4,"body":"ウイング","offDuty":false,"loginId":"driver-01"}`。通常は `{revision,driver}`。新規で `loginId` を指定すると運転手とログインを一緒に作り、`{revision,driver,user,temporaryPassword}` を返します |
| 同上 | `{"id":"担当A","name":"担当B"}` で改名、`{"id":"担当A","disabled":true}` で使用停止。停止時は担当履歴を保存し、対応するログインを停止してセッションを失効させます |
| `GET /api/admin/customers` | `{customers:[取引先の登録行,…]}`。使用停止を含みます |
| `POST /api/admin/customers` | 新規例 `{"name":"取引先A","reading":"とりひきさきえー","closingDay":20,"memo":"請求書は月締め"}`。更新・使用停止も同じ入口。応答は `{revision,customer}` |
| 同上 | `{"id":"まとめ元ID","mergeInto":"残すID"}` で統合。元の名前を持つ便と候補の選択回数をまとめ先に移し、元の登録を一覧から除きます。応答の `customer` は残した取引先です |

運転手の改名は既存の便・予定の担当名に同じ版で反映されます。本人用の便ID、作業記録、ログインとの対応は維持されます。取引先を改名・統合すると便の取引先名と選択回数に反映され、旧名で届く新しい便も保存時に現在の名前に揃います。

### 会社の項目

会社情報の読み書きにはA5の `settings.issuer` を使います。更新例は `{"issuer":{"reading":"かくううんそう","openingTime":"08:30"}}` です。`companyName` は `issuer.name` と同じ会社名、`garage` は `issuer.garages[0].municipality` と同じ市区町村を示します。どちらの書き方でも更新できます。同時に送る場合は値をそろえてください。A1〜A5の車庫は先頭の車庫として読めます。

| `issuer` のキー | 意味と入力形式 |
|---|---|
| `name, reading, representative` | 会社名・よみ・代表者名。各256文字まで |
| `postal, address, address2` | 郵便番号は半角7桁でハイフン可。住所の各行は512文字まで |
| `tel, fax, email, website` | 電話とFAXは数字・電話番号の記号で各40文字まで。メールは254文字まで。ホームページは `http` か `https` のURLで2048文字まで |
| `registration, bankText` | 適格請求書登録番号は半角の大文字Tと数字13桁。振込先は改行を含む自由文8192文字まで |
| `logo` | PNG・JPEGのBase64データURL。復号後1,048,576バイトまで。空文字で消去。会社のSQLiteに保存し、請求書と送付状の画像にはこの値を使用 |
| `openingTime, closingTime, closedWeekdays` | 営業の開始・終了は24時間表記の `HH:mm`。休業日は日曜を0、土曜を6とする整数の配列で重複不可 |
| `garages` | 最大100か所の配列。各車庫は `{name,municipality,address}`。車庫名・市区町村は各256文字、住所は512文字まで |
| `footNote, faxGreeting` | 請求書の備考とFAX送付状のあいさつ文。各4096文字まで、改行可 |

文書の税・支払条件は同じ設定APIの `invoiceRules` にあります。項目と初期値は下の「請求書」を参照してください。会社の私的な項目は管理者の設定APIで読みます。発行済み請求書は発行時の内容で表示します。

### 運転手と車の項目

1行で運転手1人と車1台を表します。日付は実在する `YYYY-MM-DD`、未入力は空文字です。重さ・寸法は0以上の有限数で、未入力は null です。文字列の選択欄は空文字で解除できます。

| キー | 意味と入力形式 |
|---|---|
| `id, name, reading` | 固定ID・名前・よみ。名前とよみは各128文字まで |
| `tel, email` | 電話は32文字、メールは254文字まで。管理者の詳細一覧、管理者・配車係の連絡先用表示で取得 |
| `hiredOn, licenseType, licenseExpiresOn, healthCheckOn` | 入社日、免許の種類（128文字まで）、免許の期限、健康診断の予定日 |
| `daysOff, offDuty, disabled, memo` | 定休曜日は0（日）〜6（土）の配列。`offDuty` は休み、`disabled` は使用停止の真偽値。人のメモは4000文字まで |
| `vehicle, plate, tons, body` | 車番とナンバー全体は各128文字。積載量はトン。車体は `平`・`ウイング`・`箱`・`冷凍冷蔵`・`ユニック`・`その他` |
| `floorHeight, airSuspension, powerGate` | 床は `低床`・`高床`。エアサスとパワーゲートは true（あり）・false（なし）・null（未入力） |
| `cargoLengthCm, cargoWidthCm, cargoHeightCm` | 荷台の内寸。長さ・幅・高さをcmで指定 |
| `vehicleInspectionExpiresOn, maintenanceDueOn, insuranceExpiresOn` | 車検・点検・保険の期限 |
| `etcLast4, fuelLast4, spareVehicle, vehicleMemo` | ETC・燃料カードは各々、下4けたを半角数字の文字列で指定。空文字で消去。予備の車は true・false・null。車のメモは4000文字まで |

### 取引先の項目

各配列は丸ごと更新します。空配列で解除できます。住所・連絡先・担当者・請求・差出人・メモの詳細は管理者用一覧で取得します。ボードで読める候補項目は下の「全体を読む」を参照してください。

| キー | 意味と入力形式 |
|---|---|
| `id, name, reading, honorific, category` | 固定ID・名前・よみ。名前とよみは各128文字まで。敬称は `御中`（既定）・`様`。種別は `荷主`・`同業`・`その他` |
| `postal, address, address2, tel, fax, email` | 郵便番号は半角7桁でハイフン可。住所は各512文字まで。電話・FAXは数字と電話番号の記号で各32文字まで。メールは254文字まで |
| `contacts` | 最大100人の配列。担当者ごとに `{name,department,tel,email,memo}`。名前・部署は各128文字まで、電話・メールは取引先と同じ形式、メモは4000文字まで |
| `invoice, closingDay` | `invoice` の `closingDay,payMonthOffset,payDay` が請求条件。各項目は null で会社の決まりを継承。最上位の `closingDay` はA3互換の1〜31（31が月末）またはnull |
| `deliveryMethod, deliveryDestination, effectiveDeliveryDestination` | 送り方は `FAX`・`メール`・`郵送`・`手渡し`。送り先にはFAX番号かメールアドレスを指定。`effectiveDeliveryDestination` は読み出し時の実効値。送り先が空なら `FAX`・`メール` に応じ取引先の `fax`・`email` を返す |
| `billingName, tollTreatment, registration` | 別の請求宛名は128文字まで。高速代は `別に請求`・`運賃に込み`。登録番号は半角の大文字Tと数字13桁 |
| `senderEmails, senderDomains, senderFaxes` | 依頼の差出人を照合するためのメール・ドメイン・FAX番号の配列。各100件まで。ドメインはメールのアットマーク以降（253文字まで） |
| `origins, destinations, requiredTons, requiredBody` | 積地・卸地は各100件までの文字列配列、1件256文字まで。必要な重さは0以上のトン数またはnull。必要な車体は運転手の `body` と同じ選択肢 |
| `memo, disabled` | 事務メモは4000文字まで、改行可。使用停止は真偽値 |

### 期限の知らせ

管理者の `GET /api/admin/reminders` は `{reminders:[{driverId,name,vehicle,kind,label,dueDate,daysRemaining},…]}` を返します。`kind` は運転手・車の期限項目名、`label` は車検・点検・保険・免許・健康診断です。日本時間の今日を0日として、過ぎた日（負の値）から60日後までを期日順に返します。使用停止の行と未入力の期日は対象外です。

### 資料のフォルダーと設定の案

管理者が `POST /api/admin/settings` に `{"documentFolder":{"path":"D:/sample/documents","enabled":true}}` を送ると、この端末の指定フォルダー直下を読み取ります。`path` はローカルの絶対パス（4096文字まで）、既定は `{"path":"","enabled":false}` です。サーバー起動時・稼働中は約30秒間隔で確認し、案の一覧を開くとその時点でも確認します。ファイルは元の場所に残り、同じ内容は名前を変えても一度だけ案になります。入切を「切」にすると新しい読み取りが止まり、登録済みの案は一覧に残ります。

| 管理者の入口 | 要求と応答 |
|---|---|
| `GET /api/admin/proposals` | `{proposals:[案,…],scanStatus:{state,filesWithErrors,filesAwaitingReader}}`。`state` は `disabled`（切）、`ready`（読み取り済み）、`unavailable`（フォルダーを開けない）、`partial`（一部失敗）。2つの件数は読めなかった資料と、文書の読み手を待つ資料 |
| `POST /api/admin/proposals/<id>/accept` | 例 `{"fields":["name","address"]}`。各値の `key` のうち入れるものを選択。対象を指定する場合は同じ本文の `targetId` に既存の取引先か運転手の固定IDを指定。成功は `{revision,proposal}` |
| `POST /api/admin/proposals/<id>/dismiss` | 本文は `{}` または空。成功は `{revision,proposal}`、状態は `dismissed` |

案には `id,fileName,target,targetId,mode,needsTarget,fields,status` があります。`target` は `company`（会社）、`customer`（取引先）、`driver`（運転手と車）。`mode` は `create`（新規）か `fill`（既存の空欄を埋める）です。各項目は `{key,current,read,conflict}` で、`current` が今の値、`read` が資料から読んだ値です。支払条件の `key` には `invoice.closingDay` などのドット付きの名前を使います。`needsTarget:true` は該当する人や会社を指定する必要があります。

入力済みの値と読み取り値が異なる欄には `conflict:true` が付きます。その欄を選んで入れると409です。他の欄だけを選んで保存できます。新規の取引先・運転手で資料に名前がある場合は名前も選びます。名前がない資料から仮登録する場合は、運転手は車番かナンバー、取引先は登録番号・メール・電話・FAXのうち少なくとも1項目を選びます。複数の候補があるときは `targetId` を指定して対象を確かめられます。

`new`（新しい案）から、選んだ項目を保存した時点で `accepted`（入れた）、見送りは `dismissed` になります。決定済みの案には `selected` が付きます。同じ決定の再送は同じ結果を返します。受け付ける時点で登録値を再確認するため、競合時は一覧を読み直してください。`GET /api/state` では未確認の件数 `proposalCount` を取得できます。

標準の読み手はCSV（UTF-8・Shift_JIS・BOM付きUTF-16LE）とxlsxを受け付けます。会社名・住所・車番・車検など、表の見出しから項目を選びます。xlsxは保存されたセルの文字・数値を読み、計算式は対象外です。1ファイル16 MiBまで、表は最大1万行・256列です。

PDF・画像・文書は、組み込み側が `new Store(dbPath,{proposalReader})` に渡す読み手で拡張できます。読み手は `async ({fileName,bytes}) => [{target,values},…]` の形で候補を返します。会社が接続したAIアカウントの読み手を渡すための入口です。標準構成では表をローカルで読みます。接続済みアカウントによる文書読み取りは将来の実装範囲です。

## 届いた依頼

### 管理者が受信を設定する

管理者画面の「届いた依頼」は `GET /api/admin/settings` の `settings.requestInbox` を表示します。既定値は次のとおりです。

```json
{"enabled":false,"source":"folder","folderPath":"","intervalMinutes":5,"imap":{"host":"","port":993,"mailbox":"INBOX"}}
```

フォルダーの受信を始めるには、たとえば次の内容を `POST /api/admin/settings` に送ります。変更する欄だけを指定でき、保存の応答は `{settings}` です。

```json
{"requestInbox":{"enabled":true,"source":"folder","folderPath":"D:/受信書類/依頼書","intervalMinutes":5}}
```

稼働中に有効にすると直ちに裏で読み取りを開始します。設定済みならアプリの起動時にも確認し、その後は指定間隔（1〜1440分の整数）で巡回します。絶対パスで指定したフォルダー直下の通常ファイルが対象です。対応形式は EML、TXT、PDF、PNG、JPEG、GIF、WebP、TIFF、BMP。上限は原本1件につき16 MiBです。元ファイルはその場所に残ります。同じメールは Message-ID、IDがないメールと他のファイルは原本全体の SHA-256 で重複を判定します。切にした後も取り込み済みの依頼・添付は開けます。

`GET /api/admin/status` の `requestInbox` は `{source,state,lastCheckedAt,added,filesWithErrors}`。日時は確認終了時のUTC ISO文字列で、初回確認前は null。件数は直近の確認で新しく保存した件数と個別に読めなかった件数です。

| 状態 | 画面の表示 |
|---|---|
| `disabled` / `checking` / `ready` | 切／確認中／確認済み |
| `unavailable` / `partial` | 受信元を開けない／一部のファイルを読めない。次回巡回で再試行 |
| `not_connected` | IMAPが未接続 |

`source:"imap"` ではホスト名・ポート（1〜65535）・メールボックス名を設定できます。標準構成では有効にしても未接続と表示されます。認証情報の入力項目はありません。組み込み試験では `createServer({store,requestImapSource})` に、`async ({host,port,mailbox}) => [{name,bytes,receivedAt}, …]` の代役を渡せます。

### 配車係・管理者が依頼を開く

`GET /api/state` の `features.requests` が true なら一覧を表示できます。`newRequestCount` は「新しい」かつ「依頼」の件数です。広告・請求・挨拶だけのメールは「その他」に残ります。運転手には依頼・添付・件数・変更履歴の入口が403、未ログインには401を返します。

| 入口 | 要求と応答 |
|---|---|
| `GET /api/requests?state=new` | `{requests:[…]}`。状態は `new`（新しい）・`accepted`（便にした）・`dismissed`（見送った）。省略・空欄は全件。他の値は400。受信日時の新しい順 |
| `GET /api/requests/<id>/attachments/<attachmentId>` | 添付のバイト列。行の `attachments[].url` をそのまま開けます。PDF・対応画像はブラウザーで表示できる形式で返し、それ以外はダウンロード用です。該当する組み合わせがなければ404 |
| `POST /api/requests/<id>/accept` | `{"trip":{"to":"架空の卸地","yen":39000,"toll":false}}` のように修正欄を送信。修正がなければ本文なし、または `{}`。成功は `{revision,request,trip}`。新しい便と `request.tripId` が同時に確定します |
| `POST /api/requests/<id>/dismiss` | 新しい依頼を見送ります。本文なし、または `{}`。応答は `{revision,request}` |
| `POST /api/requests/<id>/reopen` | 見送った依頼を新しい状態に戻します。本文・応答は見送りと同じです |

各行には `id, receivedAt, sender, senderName, senderEmail, subject, body, attachments, draft, unread, unreadable, category, state, tripId` があります。`category` は `request` または `other` で、一覧では状態と独立して絞り込めます。「その他」からも便にできます。未登録時の `tripId` は null です。メールの受信日時は上から最初の有効な Received、Date、受信元が渡した日時の順で採用します。フォルダーのファイル日時には更新日時を使います。

`draft` の `date, from, to, st, st2, yen, toll` は `/api/draft-trip` と同じ決まりで本文から読みます。「明日」などの基準は受信日の日本時間です。`unread` は読めなかった欄のキー、`unreadable` は「中身は開いて確かめる」などの案内です。`draft.customer` は差出人から照合した取引先の表示名で、候補を絞れないときは空文字です。確定時は `trip.customer` または `trip.customerId` で選び直せます。次に同じ差出人から届いた依頼には確定した取引先を優先します。

添付1件の形は `{id,name,contentType,size,url}` です。ファイル名・件名・本文は画面上でテキストとして扱ってください。添付は会社のSQLiteに保存するため、取り込み後に元ファイルが無くなっても開け、通常の会社バックアップに含まれます。会社側の文書読み取りを接続するときの入口は `createServer({store,readAttachmentText})`。関数は `async ({name,contentType,bytes}) => 文字列` で、PDF・画像の読み取り結果を下書きの元に加えます。

便にする際は、補正後の `date, from, to` が必須です。未読の運賃は null、高速の有無は確定時の既定で false になります。入力エラーは400で依頼は新しいままです。すでに別の人が処理した場合や二重送信は409となります。一覧を再取得し、成立済みの便は `tripId` で開いてください。確定した便の内容は `trip` に、読み取り時点の下書きは `request.draft` に残ります。

ボードは `GET /api/changes` の `kind:"request"` を受けて一覧・件数を読み直せます。変更前後には `{id,state,category,tripId}` が入り、受信時の `before` は null です。便を作ったときは、同じ版に通常の `kind:"trip"` も届きます。

## 請求書

管理者・配車係が `/invoices` を開けます。月の書式は `YYYY-MM`、取引先の指定にはマスターの固定 `id` を使います。

| メソッド・パス | 応答・操作 |
|---|---|
| `GET /api/invoices?month=2024-11` | `{month,invoices,summary}`。取引先ごとに `customerId,customer,month,count,total,issueCount,latest,changed,outputStatus` を返します。発行前の `latest` は null。発行済みで請求内容に差があれば `changed:true` |
| `GET /api/invoices/<取引先ID>/<月>` | `{customerId,invoice,latest,changed,history,outputStatus}`。パス中のIDは `encodeURIComponent` で符号化します。`invoice` に対象期間、支払期限、便の明細、税額、合計と確認事項が入ります。確認事項の `tripId` から `/?trip=<便ID>` に移動できます |
| `POST /api/invoices/issue` | 本文は `{month,customerId,expectedVersion}`。`expectedVersion` は任意で、未発行なら0、再発行なら表示した版です。`{number,version,issueDate}` を返します。番号は請求月と会社内のその月の連番です。同じ内容の再送は同じ版を返します |
| `GET /invoices/print?month=2024-11` | まとめて表示する印刷用HTML。`customerId` で1社に絞り、さらに `version` を付けると発行時の紙面を再表示します。版の指定がない場合は現在の内容を表示し、発行後に変更がなければ発行済みの番号と日付が付きます。`print=1` または紙面の「印刷」で、重複確認を経て印刷ダイアログを開きます |

発行元・ロゴ・備考は上の「会社の項目」で登録します。紙面には会社の住所2行と、取引先の `billingName`（未設定なら取引先名）を使います。高速代の扱いが `運賃に込み` の取引先では請求に高速代を別加算しません。

`settings.invoiceRules` の初期値は `{"taxRate":10,"rounding":"floor","tollTaxable":true,"closingDay":0,"payMonthOffset":1,"payDay":0}` です。税率は0〜100の数値、端数は `floor`（切り捨て）・`round`（四捨五入）・`ceil`（切り上げ）、高速代を課税対象にするかは真偽値です。締め日・支払日は1〜31の整数か、月末を表す0です。支払月は締め月からの月数で0〜120の整数です。取引先の `invoice` の各支払条件は null にすると会社設定を継承します。

`GET /api/state` の `features.invoice:true` を受けたボードは `tollYen`（円または null）と `invoiceNote`（文字列）を便の編集・差分保存に使えます。運転手用の便にこの2項目は含まれません。

## 印刷・FAX・メール・PDF保存の記録

記録は会社単位です。以下の入口は管理者と配車係が利用できます。端末一覧は管理者専用です。未ログインは401、運転手は403です。宛先番号・アドレスは権限のある利用者が取得する記録に含まれます。

| 入口 | 入力 | 成功時の応答 |
|---|---|---|
| `GET /api/outputs` | 任意の `kind,month,customerId,tripId` をクエリーで指定。指定した条件すべてで絞り込み | 200 `{outputs:[…]}`。新しい順で、失敗・まちがいの記録も含む |
| `POST /api/outputs/check` | 下記の書類と版 | 200 `{outputs:[…],actorId}`。すでに出した有効な記録を新しい順で返す。初回は空配列。`actorId` は照会した利用者のID |
| `POST /api/outputs` | 書類と版、出力方法、結果、必要に応じて宛先など | 201 `{output}`。`expectNone:true` の競合は409 `{error,output}` |
| `POST /api/outputs/<id>/void` | `{"reason":"別の書類の結果を登録したため"}` | 200 `{output}`。最初に印を付けた人・時刻・理由を保持 |
| `POST /api/outputs/claim` | 書類と版。保存先PCから直接接続 | 201 `{claim}`。有効な名乗りがあれば409 `{error,claim}` |
| `GET /api/me/device` | ログイン中のブラウザー | 200 `{device:{id,name}}` |
| `POST /api/me/device` | `{"name":"事務所のPC"}`。1〜128文字 | 200 `{device:{id,name}}` |
| `GET /api/admin/devices` | 管理者 | 200 `{devices:[{id,name},…]}` |

### 書類の識別と記録

発行済み請求書の例です。確認・名乗りには最初の4項目を送り、出力結果の登録で残りを加えます。

```json
{
  "kind": "invoice",
  "customerId": "sample-customer",
  "month": "2026-11",
  "version": 1,
  "method": "fax",
  "destination": "03-0000-0000",
  "result": "done",
  "expectNone": true,
  "operationId": "29189bf0-970c-41b3-a2bb-02bf8a09802a"
}
```

- 同じ書類かどうかは `kind,month,customerId,tripId,version` の組で判断します。端末・担当者・出力方法が異なっても照合します。`invoice` は取引先ID・月・発行済みの正の整数版が必須です。存在しない発行版は404です。
- 種類は64文字までの文字列を追加できます。たとえば送付状は `fax-cover`、高速の利用証明書は `toll-certificate`、運行指示は `trip-instruction` とし、画面と自動処理で名前と対象の組を統一します。月（`YYYY-MM`）・取引先ID・便IDのいずれかと、版を指定します。版には正の整数または128文字までの版名を使えます。数字だけの版名は整数にそろえます。
- `method` は `print`・`fax`・`email`・`pdf`、`result` は `done`（既定）または `failed` です。失敗は `reason` が必須です。理由は1024文字まで、任意の `destination` は512文字までです。
- 記録には書類の識別項目、`id,method,result,reason,destination`、出力者の `actorId,actorName`、UTC日時 `at`、当時の `deviceId,deviceName` が入ります。まちがいの印は `voidedAt,voidedBy,voidedByName,voidReason` に残り、印を付けるまでは null です。
- 二重確認には成功かつ有効な記録を使います。画面は `check` の先頭にある人・時刻・方法を見せます。初回は `expectNone:true` を付けて保存します。確認中に相手が登録したときは409の `output` を見せ、利用者が今回の分も残すと選んだら `expectNone` を外して送ります。すでに出した記録を見て再出力を了承した場合も同様です。
- `operationId` は任意のUUIDです。利用者・出力操作ごとに一度生成し、通信エラーの再試行や409を了承した後の登録には同じ値を使います。同じ利用者が保存済みの同一内容を再送すると元の1件が返ります。異なる内容でのID再利用は409 `{error}` です。
- 共有ブラウザーでは最初の `check` が返した `actorId` を覚え、続く照会・登録・再試行に `X-Acting-User: encodeURIComponent(actorId)` を付けます。その間に別の人へログインが切り替わった場合は403です。元の担当者で入り直すと、開いている紙面から記録を再試行できます。

### 請求画面と紙面

請求一覧の各行と明細の `outputStatus` は `{printed,sent}` です。`printed` は印刷、`sent` はFAX・メールのうち直近の有効な記録です。それぞれ `actorName,at,method` を表示でき、該当する記録がないときは null です。対象は `latest.version` で、再発行の直後は両方とも null になります。PDF保存や下書きの印刷は履歴で確認できます。

紙面の部品は表示時に確定した取引先・月・版で照合します。未発行または訂正中の紙面は `kind:"invoice-draft"` とし、内容と紙面の日付に基づく64桁の版を使います。まとめ印刷では各社の紙面を確認し、ダイアログを閉じたあと、利用者が実際に紙に刷れたと答えたものを記録します。保存だけ失敗したときは、開いている紙面の「印刷記録を再試行」から登録をやり直せます。

### 自動出力の担当と端末名

`claim` は、サーバーが見た直接のループバック接続で受け付けます。転送を示す `Forwarded`・`X-Forwarded-*`・`X-Real-IP`・`Via` つきの接続は403です。同じ書類・版で先着1件が5分間担当します。`claim` に担当者・端末・開始時刻 `at`・終了時刻 `expiresAt` が入り、期限以降は再取得できます。名乗りの取得は、出力完了の記録とは別の操作です。

端末はブラウザーの会社別の永続Cookie（HttpOnly）で識別します。同じブラウザーでログインし直しても名前を引き継ぎます。ブラウザーを替えたりCookieを消したりすると新しい端末が作られます。担当者・端末名・時刻は保存先で確定し、過去の記録は当時の名前で表示します。

## 画面の接続

`GET /` はセッションの役目で出し分けます。配車ボードには `window.DISPATCH_API='/api'`、運転手用画面には `window.DRIVER_API='/api/my'` が設定されます。試作にある全員分の埋め込みデータや名前選択を運転手へ配信しません。現在は運転手HTMLのスタイルと、このアプリのAPI接続用画面を組み合わせています。

Claude側の運転手HTMLを直接つなぐときは、埋め込みの便・名簿、名前選択、試作用の端末保存を外し、`<head>` に次を入れます。

```html
<meta name="haishashitsu-driver" content="api-v1">
```

この形式では自作の画面とスクリプトがそのまま配信されます。利用者は `GET /api/me`、便は `GET /api/my/trips` で取得します。共通部品がマニフェスト・Service Worker・ログアウトを用意します。ログアウトの位置を決めるには `<button type="button" data-hs-logout>ログアウト</button>` を置きます。未送信操作の保持と再送は、この形式に切り替えた運転手HTML側で行います。目印と従来の試作データ・選択画面が混在した場合は503で配信を止めます。

ホーム画面用のマニフェストは `/manifest.webmanifest`、Service Worker は `/sw.js` です。キャッシュ対象はマニフェスト・アイコン・CSS・JavaScriptに限定します。運転手が便を開いた後に通信が切れた場合、進行ボタンの未送信操作を本人別に記録し、同じアカウントで通信が戻った際に再送します。便画面の新規表示・再読込、連絡・写真・取り消しの保存には通信が必要です。

配車ボードに運転手の実績を表示するときは、便の詳細で `driverReport.steps` の時刻、`driverReport.memo` の連絡、`driverReport.hasPhoto` の「写真あり」を表示します。読み込み後の更新は `kind:"trip"` の差分から受け取ります。担当変更で前任者の記録は履歴に残り、新任者の便は空の記録から始まります。

### 配車ボード側の初回表示とマスターの反映

- 運転手・便が0件でも `/api/state` の応答で初期表示します。管理者はボード内の「設定」から登録を始めます。設定画面は `features.masters === 2` で追加欄の利用可否を判断できます。
- 配車候補には使用中の運転手を表示し、`offDuty` で休みを示します。`disabled` の運転手も過去の便の表示に使えます。取引先の入力候補は `state.customers` を使うと、まだ便がない取引先も選べます。件数・表示順の判断には `picks`、場所の候補には `places`・`geo`・`settings.garage` を使えます。
- 運転手・車のマスター変更は `kind:"driver"`、取引先の候補変更は `kind:"customer"` で届きます。対応する便・予定の差分も同じ版に含まれます。画面で個別の差分を扱えない場合は、その版を受け取った時点で `/api/state` を読み直すと表示を揃えられます。

## 起動と差分の同期

`GET /api/health` はログイン前も `{"ok":true}` を返します。以下のA1 APIは配車係・管理者用です。

1. 画面側はAPIの合図があるときに `GET /api/state` を待って初期描画します。配信するHTMLでは同一オリジンのAPIへの通信を許可します。
2. 便・予定を編集し始めた時点の版を保持します。保存・削除・取り消し・やり直しは、対象IDの変更だけを `POST /api/changes` に送ります。新規IDは省略して返却値を使うか、画面で `crypto.randomUUID()` を生成します。
3. 成功時は応答の値で表示を更新します。差分取得用の版は別に持ち、最後に**取り込み済み**の版から `GET /api/changes?since=…` を呼びます。自分の保存が成功した時点で差分取得用の版を進めると、その直前にほかの画面で確定した変更を取りこぼします。
4. 競合時は入力を保持し、409の現在値を示します。利用者が差分を確認してから、修正内容と確認した版で再送します。取り消しもその操作の前後値と版を使い、無関係な行を一括で戻すことを避けます。

## 全体を読む

`GET /api/state` は1つの版で以下の全項目を返します。地名・位置の配列は試作の `normalizeData` と一緒に配布されていた辞書と同じ形式です。

| 項目 | 内容 |
|---|---|
| `revision`, `today` | 会社DBの現在の整数版、日本時間の今日 |
| `trips`, `blocks` | 保存中の便・休み等の配列 |
| `features` | `{"invoice":true,"masters":2,"requests":true}`。`masters` は会社・運転手・車・取引先の登録項目の版 |
| `newRequestCount` | 届いた依頼のうち `state:"new"` かつ `category:"request"` の件数 |
| `proposalCount` | 資料から読み取った未確認の案の数。案の本文は管理者の一覧から取得 |
| `onboardingReviewCount` | 最初の取り込みで確認する行数。自社は項目ごと、取引先・車・運転手は対象ごとに1行と数える |
| `drivers` | 名前のある運転手と車。ボードで使う `id,name,reading,vehicle,plate,tons,body,offDuty,disabled,daysOff,floorHeight,airSuspension,powerGate,cargoLengthCm,cargoWidthCm,cargoHeightCm,spareVehicle`。以前の取り込みで省略した欄もあり、IDは `id ?? name`、休み・停止の省略時は false |
| `customers` | 使用中で名前のある取引先名の文字列配列。従来の候補欄で使用 |
| `customerDefaults` | 同じ取引先の `{id,name,reading,origins,destinations,requiredTons,requiredBody}` の配列。便を追加するときに積卸地と車の条件を選ぶための候補 |
| `places` | 各候補は [市区町村名, 都道府県, 読み, ローマ字, 郡, 区, 区の読み, 区のローマ字, 郡の読み] |
| `geo` | [都道府県, 経度, 緯度, [[市, 区, 郡, 経度, 緯度], …]] の配列 |
| `picks` | 選択回数。例 `{"c:得意先A":2,"p:北港":1}` |
| `settings`, `ai` | ボード用の会社設定（初回設定後は `companyName,garage`）。自動取り込みの設定・状態は管理者用APIで取得します。AI状態は `{"linked":false}` |

新規保存先では `trips, blocks, drivers, customers` はすべて `[]`、`picks` は `{}` です。データの取り込み前から、全国の市区町村と位置情報が `places, geo` に入ります。

便には `id, driver, vehicle, date, end, from, fromPref, to, toPref, st, st2, et, et2, time, customer, yen, toll, mark, memo, agreement, tentative, requiredTons, requiredBody` があります。日をまたぐ時間幅には `stWindowEndDate, etWindowEndDate` も付きます。`st/st2` は積む時間幅、`et/et2` は卸す時間幅、`time` は元の時間メモです。運転手未定は `driver:""`、未入力の運賃・必要トン数・成約IDはnull、`toll, tentative` は真偽値です。

## 便と予定を保存する

`POST /api/changes`。必須は `baseRevision`。4つの配列 `trips, removed, blocks, removedBlocks` は省略できます。追加・更新はオブジェクト配列、削除は文字列IDの配列です。既存IDは指定項目だけを更新します。新しい手入力便には `date, from, to` が必要です。`end` を省略すると新規は当日になります。新規予定には `date`、`driver` または `vehicle`、`kind` または `label` が必要です。

```json
{
  "baseRevision": 12,
  "trips": [{"id":"t1","date":"2026-11-28","from":"北港","to":"南港","st":"09:00"}],
  "removed": [],
  "blocks": [{"id":"b1","vehicle":"車A","date":"2026-11-29","kind":"整備"}],
  "removedBlocks": []
}
```

成功応答は `{revision,trips,blocks}`。後の2つはこの要求で保存した行の全項目を持つ配列で、削除行は含みません。たとえば削除だけが確定した応答は `{"revision":14,"trips":[],"blocks":[]}` です。1要求内の全変更は同時に確定します。実質的な変更がない保存で版は進みません。

対象に別の確定変更があると409になり、同時に送った他行も保存されません。古い版でも対象行に変更がなければ受け付けます。削除済みのIDも競合を検出します。例は削除済みの便です。

```json
{"error":"他の変更と競合しました","revision":15,"conflicts":[{"kind":"trip","id":"t1","current":null}]}
```

生きている行の `current` には全項目を返します。未来の版、無効な日時・型、同一種類の同じIDを1要求で複数指定した場合は400です。

## 変更記録と候補

`GET /api/changes?since=14` は指定版より後の全記録を確定順に返します。記録がないときもその時点の版を返します。1回の保存に由来する記録は同じ版です。`actor` は操作したログインIDで、初期取り込み・自動取り込み・A1で保存した記録はnullです。

```json
{"revision":15,"changes":[{"revision":15,"at":"2026-11-25T08:00:00.000Z","actor":"sample-desk","kind":"pick","id":"p:北港","before":1,"after":2}]}
```

`kind` は `trip, block, driver, customer, pick, settings, places, geo, proposal, request`。`since` は現在版以下の非負整数です。追加前・削除後の値はnullです。便・予定の `before, after` は該当行全体、選択回数は数値、設定はボード公開項目の値です。運転手の記録は `state.drivers` 用の項目に限定されます。取引先の記録は固定 `id` と、その前後のボード用の有効な名前（文字列）またはnullです。使用停止・統合では `after` は null です。候補の地名・車の条件を変えたときも名前は同じなので `customerDefaults` を再取得してください。

`kind:"proposal"` は案の `id` と、変更前後の状態（例 `{"status":"accepted"}`）を返します。件数を更新するときは `proposalCount` を読み直せます。運転手の電話・メール、カードの下4けた、振込先、案の読み取り値はボード・本人の便・変更記録には入りません。

`POST /api/picks` に `{"kind":"place","value":"北港"}` を送ると、例えば `{"revision":15,"kind":"place","value":"北港","count":2}` を返します。`kind` は `place` または `customer`。正規化して同じ候補にまとまった場合は、返却された表記を回数のキーに使います。画面の候補順位には会社DBの回数を使います。

## つなぐ先

会社ごとに管理者が操作します。新しい会社のトラボックス接続は切です。配車係・運転手は403、未ログインは401です。送信には同一オリジンの JSON POST を使います。

| 入口 | 本文と応答 |
|---|---|
| `GET /api/admin/connections` | `{connections:[…]}`。順番は `trabox, mail, fax, ai` |
| `GET /api/admin/connections/trabox/fields` | 200で `{ownProfile,companyProfiles,agreements,deliveryOrders}`。自社プロフィール、相手会社プロフィール、成約、配車の各レコードで観測した項目名を文字列の配列で返します |
| `POST /api/admin/connections/<kind>` | `{enabled?,settings?,id?,password?}` → `{connection}`。IDとパスワードを登録・交換するときは両方送ります。切にする操作は `{"enabled":false}` |
| `POST /api/admin/connections/<kind>/test` | 本文は空または `{}`。単発の疎通結果は `{connection:{…,test:{ok,reason}}}`。200でも `test.ok` を確認してください。トラボックスは保存済みの資格情報でログインまたは自社プロフィールの読み取りを1回行います。成約・荷物の巡回には数えません |
| `POST /api/admin/connections/<kind>/disconnect` | 本文は空または `{}`。資格情報とセッションを消し、`{connection}` を返します |

項目名は、最初の取り込みまたは見直しの全ページが完了した時点で更新します。各配列はレコード直下からのパスを重複なく昇順に並べます。例えば `phone.number` はオブジェクト内の項目、`accounts[].branch` は配列内の項目を表します。空の配列でも `accounts[]` を記録します。一覧に含まれるのは項目名だけです。項目の値が空でも名前は残るため、名前の有無と値の登録状況は別です。初回の完了前は4つとも空配列です。見直しの途中は直近の完了分を返し、明示的な切断や別の接続IDへの変更で消去します。このGETは保存した一覧を返し、トラボックスへの通信は発生しません。

`connection` は `kind, enabled, state, lastSuccessAt, lastFailure, nextAttemptAt, hasCredentials, settings`。時刻はUTCのISO文字列、未取得・次回未定は null です。`lastSuccessAt` は最後に取得が完了した時刻です。`lastFailure` は表示用の日本語、`hasCredentials` は登録の有無です。ID・パスワードの入力は新規値だけを受け付ける欄にし、送信後にクリアしてください。

| 状態 | 表示・操作 |
|---|---|
| `disabled` / `waiting` / `checking` / `ready` | 切／取得待ち／確認中／接続済み |
| `stopped` | 「止まっています」と理由を表示。認証拒否（401・403）、回数制限（429）、版・形式の変更、資格情報の復号失敗で停止状態を保存します。「もう一度つなぐ」で `{"enabled":true}` を送ります。通常の設定修正では `enabled` を省略してください |
| `unavailable` / `partial` / `not_connected` | 取得失敗／一部を読み取れない／未接続。理由と次回時刻を併記します |

トラボックスの `settings` は `{}`。管理者が資格情報を登録して入にすると、稼働中のサーバーが約30秒ごとに取得時刻を確認します。成約は15分以上、荷物は60分以上空けます。各HTTP要求は順番に前の終了から200ms以上空けます。再起動・入切・手動取得も保存した間隔を守ります。テスト中・巡回中の重ね押し、停止中のテストは409です。荷物は取得日（日本時間）から30日分を全国・全車種・運賃要相談を含めて取得します。全ページを確認後に一覧を更新し、消えた荷物と掲載終了の荷物を候補から外します。終了行は24時間経過後の清掃対象です。取得失敗時は直近の完全な一覧と成功時刻を維持します。

成約は既存の成約番号で照合します。登録済みの車・運転手を成約から特定できた場合は、新規の便に割り付けます。接続を有効にした直後にも取得時刻を確認します。会社情報と名簿の確認には「最初の取り込み」のAPIを使います。

`mail` の設定は `{host,port,mailbox,intervalMinutes}`、`fax` は `{folderPath,intervalMinutes}`。既存の `settings.requestInbox` と同じ受信元を使い、一度に有効な受信元は1つです。FAXは設定済みフォルダーを読みます。標準構成のIMAPとAIには `not_connected` を表示できます。AIの `settings` は `{}` です。

## 最初の取り込み

以下の4つの入口は管理者用です。配車係・運転手には403、未ログインには401を返します。最初の取り込みと再見直しでは、自社プロフィール、成約の全ページ、相手会社のプロフィールと配車情報を順に読みます。最後のページの件数照合が済むと、新しい便と確認用の一覧が同時に利用できます。

| 入口 | 本文と応答 |
|---|---|
| `GET /api/admin/onboarding` | 200。下記の状態、集計、進み具合を返す |
| `GET /api/admin/onboarding/items?kind=customers` | 200で `{kind,items}`。種類は `company`、`customers`、`vehicles`、`drivers` |
| `POST /api/admin/onboarding/apply` | `{"kind":"customers","all":true,"skipConflicts":true}`。個別選択は `all` の代わりに一覧の `ids` 配列を送る。200で `{revision,applied,skippedConflicts}`。適用直前の値で再照合する。再送で既に同じ値なら加算しない |
| `POST /api/admin/onboarding/rescan` | 本文は空または `{}`。202で見直しを予約し、状態を返す。取得時刻を迎えたら開始する。既に取得中ならその続き。切断中・停止中は409 |

状態 `state` は `idle`（接続前）、`collecting`（予約または収集中）、`review`（確認項目あり）、`done`（確認項目なし）、`stopped`（接続停止）です。`completedAt` は最後の全件読み取りが完了した時刻、`earliestDate`・`latestDate` は読み取った有効な成約の積日範囲です。日付のない成約は空欄の便として保存します。`progress` の `nextPage,received,totalPages,totalRecords` には再開するページ、確定済みページの通算行数、相手が返した総ページ数、総行数が入ります。総数は取得前は null です。無効な成約はページの照合に含め、便からは除きます。

`summary` の `agreements` は読み取った有効な成約数、`customersNew / customersFill` は取引先の新規・補完の案数です。`vehicles / drivers / companyFields` は車・運転手・自社項目の案数、`conflicts` は食い違いの項目数です。照合先を一つに決められない場合も1件と数えます。`reviewCount` は確認する行数です。集計は直近の完了済みデータと現在の登録値に基づきます。

一覧の各行は `id, kind, label, mode, targetId, fields, conflict, needsTarget` を持ちます。`mode` は `create` または `fill`。`fields[]` の `key,current,read,conflict` で値を並べ、取得元同士に違いがあれば `alternatives`、登録形式に合わなければ `invalid` を表示できます。照合先が複数なら `matchingIds` が付きます。食い違う項目は適用後も一覧に残り、必要に応じて通常の設定で確認できます。`skipConflicts` の既定値は true です。false は400、取得中の適用は409になります。

取引先のFAXはA6の差出人照合にも使います。取引先ごとの積地・卸地は保存済みの便から頻度順に提案し、既存の場所を保持します。候補の回数 `picks` は同一成約の再取得で増えません。車番だけの登録は管理者の運転手・車一覧で `name:""` として取得できます。取引先の担当者名・電話番号は管理者用の一覧・詳細で扱います。

相手会社のプロフィールに次の項目があれば、`items?kind=customers` の `fields[].key` に取引先別の請求条件が出ます。

| プロフィールの項目 | 一覧のキー | 読み替え |
|---|---|---|
| `cutOffDay.code` | `invoice.closingDay` | 締め日。1〜31はその日、99は月末（0） |
| `paymentMonth.code` | `invoice.payMonthOffset` | 締め月から支払月までの月数。0〜120の整数で、0は当月、1は翌月 |
| `paymentDay.code` | `invoice.payDay` | 支払日。1〜31はその日、99は月末（0） |

数値型の整数コードを読み取ります。欠落や範囲外、型が違う項目があっても、残りの有効な項目を確認・登録できます。選択登録・一括登録とも、取引先に設定済みの値と異なる項目は食い違いとして残ります。登録後はA5の請求期間と支払期限に反映され、取引先で未設定の条件には会社の既定値を使います。自社プロフィールのこの3項目は `invoiceRules` に取り込まず、営業所住所 `officeAddress` も自社の `address2` の候補から除きます。

A10で取り込みを完了した会社では、A11で「もう一度見直す」（`POST /api/admin/onboarding/rescan`）を実行すると、既存の取引先についても条件の案と項目名の一覧を取得できます。

A8の未確認の取引先案はこの一覧に移ります。A7の資料と内容が重なるときは、資料一覧に資料固有の項目が残ります。その行の `linkedCustomerName` は相手先表示に使えます。確認済みの資料の履歴は元の一覧に残ります。

変更履歴で `kind:"onboarding"` を受けたら件数を読み直してください。取得結果が変わった場合は `id:"review"`、管理者が登録した場合は種類と適用件数が届きます。読み取った担当者情報は履歴に含めません。

401・403・429・版や応答形式の変更などで停止した場合は `lastFailure` を表示します。管理者が「もう一度つなぐ」を選び、成約の次の取得可能時刻 `nextAttemptAt` に達すると、保存済みページの次から再開します。途中でページ構成・件数・IDの重複に変化を検出した場合は、次の取得で1ページ目から照合し直します。資格情報を明示的に切断したときと別の接続IDに交換したときは、前の接続の確認用データを消去します。

## 台帳の取り込みとCSV

| 入口 | 内容 |
|---|---|
| `POST /api/import/agreements` | 配車係・管理者の手動取り込み。本文は空または `{}`。直接接続が入なら登録済みの車・運転手と照合します。切なら設定済みの `sourceDir` または起動時の台帳を読み、運転手・車未定で追加します。応答は `{revision,added,trips}`。既登録・削除済み・照合保留の便は追加を見送ります。データを読めない場合は503です |
| `GET /api/export/attendance.csv?month=2026-11` | 積む月で抽出し、運転手ごとに見出し・明細と都道府県の2行・合計を出力。運賃は万円。月は必須 |
| `GET /api/export/trips.csv` | 保存中の全便の一覧。運賃は円 |

CSVはExcelで開けるBOM付きUTF-8、改行はCRLFです。セルをダブルクォートで囲み、カンマで区切ります。文字列の先頭で表計算の式として扱われる記号はエスケープします。

トラボックスを入にした会社では、上の手動取り込みも直接接続を使います。成約の次回時刻より早い場合、読み取り中または停止中は409です。直接接続の状況は `GET /api/admin/connections` に反映されます。

トラボックスが切の会社では、旧設定 `settings.import.agreements` を引き続き利用できます。`enabled:true` と対象フォルダーを保存すると15分ごとに同じ台帳を読みます。最初の定期試行も15分後です。`enabled:false` でタイマーを停止します。フォルダーからの手動・自動取り込みの結果は `GET /api/admin/status` に反映されます。新しいボードの成約設定には「つなぐ先」を使ってください。

## 文章から案を作る

`POST /api/draft-trip` に `{"text":"2026/11/28 北港から南港 9時 高速なし"}` を送った結果です。これは入力欄に入れる案で、保存は利用者の確定時に行います。

```json
{"trip":{"date":"2026-11-28","from":"北港","to":"南港","st":"09:00","st2":"","yen":null,"toll":false},"unread":["yen"],"by":"rules"}
```

今年・今日の基準は日本時間です。読めなかった欄は空文字またはnullで、`unread` に欄名が入ります。`st2` は任意の幅の終端です。高速の指定がないと `toll:null` なので、画面で未確認のまま示し、保存時に選択した真偽値を渡すか、その項目を省きます。文章は1〜16,000文字で、今回の `by` は `rules`。将来のAI接続に `ai` を予約しています。

## A8　空きに合う荷物

配車係と管理者のボードは、`GET /api/state` の `features.candidates === true` で候補検索を表示できます。`state.listings` は `{"lastSuccessAt":null,"count":0}` から始まります。`lastSuccessAt` は荷物一覧を最後まで取得できた日時、`count` はその時点で掲載中の件数です。仮便登録済みの荷物も掲載中なら件数に含みます。画面を開くときや再表示時には鮮度を読み直してください。検索は保存した一覧を使います。受信に失敗したときは前回成功時の一覧と日時が残ります。

### 空きを指定して検索する

`POST /api/candidates` に `{"driverId":"demo-driver"}` を送ると、現在以後、その運転手または登録車両を割り付けた便と休み・整備等の予定から空きを探します。`driverId` には `state.drivers` の固定ID（以前の行では `id ?? name`）を使います。前便があれば卸地から、前便がなければ会社設定の先頭の車庫から出発します。次便があればその積地までの回送を含めます。次便がなければ候補を卸した時点で行程が終わります。

特定の空きを選んだときは同じ入口に次の形で送ります。`previous` は前便の卸しを終える地点・日時、`next` は次便の積みを始める地点・日時で、片方だけでも指定できます。`at` は検索の基準日時で、省略時は現在です。タイムゾーンなしの入力は日本時間として扱います。緯度経度はサーバーの市区町村辞書から引くため、同名の地名には都道府県を付けてください。

```json
{
  "driverId": "demo-driver",
  "at": "2030-06-03T08:00:00+09:00",
  "previous": {"place":"東京都立川市","at":"2030-06-03T08:15:00+09:00"},
  "next": {"place":"東京都羽村市","at":"2030-06-03T12:00:00+09:00"}
}
```

車の条件を直接指定する場合は `driverId` を省き、例えば `"vehicle":{"name":"試験車","tons":4,"body":"ウイング","floorHeight":"高床","powerGate":true}` を送ります。`name` を指定すると、その車に登録した便・予定も照合します。`tons` はトン数、`floorHeight` は「低床」「高床」または空文字、`powerGate` と `airSuspension` は真偽値または null です。定休曜日・休みの判定には運転手IDを使ってください。

検索成功は200で `{"candidates":[…]}`、該当なしは `{"candidates":[]}` です。上の空きに合う架空の荷物を既定単価で計算した応答例です。

```json
{
  "candidates": [{
    "id": "999999999991",
    "from": "東京都八王子市",
    "to": "東京都青梅市",
    "pickup": {"date":"2030-06-03","timeFrom":"09:00","endDate":"2030-06-03","timeTo":"10:00","raw":"2030-06-03 09:00〜10:00"},
    "delivery": {"date":"2030-06-03","timeFrom":"10:30","endDate":"2030-06-03","timeTo":"11:00","raw":"2030-06-03 10:30〜11:00"},
    "pickupAt": "2030-06-03T09:00:00+09:00",
    "deliveryAt": "2030-06-03T10:30:00+09:00",
    "fare": 42000,
    "weight": "4t以下",
    "body": "ウイング",
    "share": false,
    "highway": true,
    "deadheadBefore": {"from":"東京都立川市","to":"東京都八王子市","km":13,"minutes":13},
    "loaded": {"from":"東京都八王子市","to":"東京都青梅市","km":19,"minutes":19},
    "deadheadAfter": {"from":"東京都青梅市","to":"東京都羽村市","km":5,"minutes":5},
    "totalKm": 37,
    "fuelYen": 1388,
    "tollYen": 925,
    "estimatedBalance": 39687,
    "slackMinutes": 85,
    "checks": ["受付場所を確認"],
    "lastSeenAt": "2030-06-02T22:00:00.000Z"
  }]
}
```

| 返る項目 | 画面での意味 |
|---|---|
| `id, from, to, weight, body` | 荷物番号（文字列）、積地・卸地、掲載された重さの区分・車体条件 |
| `pickup, delivery` | 積み・卸しの掲載上の時間幅。日本時間の `date + timeFrom` から `endDate + timeTo` まで。`raw` は元の日時表記。「指定なし」は00:00〜23:59、「午前」は00:00〜11:59、「午後」は12:00〜23:59。23:00〜翌01:00など日をまたぐ場合は終了日の `endDate` を使用 |
| `pickupAt, deliveryAt` | 回送と空きを照合し、各時間幅の中で成立した積み・卸しの見込み日時（日本時間・分単位） |
| `share, highway` | 掲載上の積合・高速代の有無。各々 true・false・null（未指定） |
| `deadheadBefore, loaded, deadheadAfter, totalKm` | 積地へ向かう回送、荷物を積んで走る区間、次便の積地までの回送、3区間の合計km。各区間には発着地と見込みのkm・分。次便がなければ `deadheadAfter` は null |
| `fare, fuelYen, tollYen, estimatedBalance` | 掲載運賃、見込み燃料費、見込み高速代、残額見込み。単位は円。要相談の運賃とその残額は null |
| `slackMinutes, checks, lastSeenAt` | 次便の積みまでの余裕（卸した後の回送も差し引いた分数、次便なしは null）、確認する備考等の文字列配列、その荷物を最後に取得できた日時 |

### 車・時刻を判定する条件

- 通常の `4t` は積載量4t以上、`4t以下` は4tを含む上限です。「未満」「以上」「超」、上下限付きの範囲も照合します。車体が「ウイング又は平」ならどちらかが必要です。低床不可・高床指定は車の床の高さと照合します。掲載条件に必要な車体・積載量等を確認できない車は候補から外れます。自由記述の作業条件は `checks` で確認します。
- 同じ運転手・車の既存便、整備・休みの予定をまたぐ行程は除きます。ボードの既存便に時間幅があれば、次便は積む幅の開始、前便は卸す幅の終了を境にします。休みの運転手は0件です。定休曜日には回送を含む行程を割り付けず、掲載時間の幅に余地があれば休み明けの成立時刻も探します。
- 前の卸地から積地へ間に合い、実車で卸せる時間幅に着き、後の回送を終えて次便に間に合う荷物が対象です。早着した場合は掲載時間幅の開始まで待ちます。行程には見込みの走行時間を使い、荷役・現場待ち・休憩の個別所要時間は加算していません。
- 残額見込みが大きい順に最大30件を返します。同じ荷物が複数の空きに入る場合は合計距離の最も短い行程を返します。残額が同じときは積みの成立日時、荷物番号で順を決めます。要相談の荷物は金額を計算できる候補の後に並びます。

### 距離と残額の計算

配車ボードと同じ `geo` の市区町村代表地点を使います。陸続きの区間は大圏距離に30km未満は1.35、30km以上90km未満は1.28、90km以上は1.22を掛けます。本州・四国・九州・淡路島の間はボードと同じ橋の取り付き地点と区間距離を経由します。各区間を整数kmに四捨五入し、異なる市区町村間は最低3km、同じ代表地点は0kmとします。時速60kmで1kmを1分と数えます。片方の市区町村が特定できない場合や、ボードでフェリー所要時間が不明な区間は候補から外れます。

管理者は `GET /api/admin/settings` の `settings.candidateCosts` で単価を読み、`POST /api/admin/settings` に例えば `{"candidateCosts":{"dieselYenPerLiter":155}}` を送って個別に更新できます。

| 設定名 | 単位 | 既定値 | 入力できる数値 |
|---|---|---:|---:|
| `kmPerLiter` | 燃費（km/L） | 4 | 0.01〜1,000,000 |
| `dieselYenPerLiter` | 軽油単価（円/L） | 150 | 0〜1,000,000 |
| `tollYenPerKm` | 高速代の見込み単価（円/km） | 25 | 0〜1,000,000 |

合計kmは前回送・実車・後回送の合計です。燃料費は「合計km × 軽油単価 ÷ 燃費」、高速代は「合計km × 高速代の見込み単価」をそれぞれ1円単位で四捨五入します。残額見込みは「運賃 − 燃料費 − 高速代」です。掲載上の高速代の有無は `highway` に表示し、見込み費用は全走行区間に同じ単価を適用します。高速代の別請求額は加算していません。応答例では37km、燃料費1,388円、高速代925円で、42,000円の運賃から39,687円が残る試算です。

### 候補を仮の便にする

`POST /api/candidates/<荷物番号>/take` に、検索に使った運転手・車と空きの条件をもう一度送ります。パスに入れる番号は `encodeURIComponent(candidate.id)` を使います。運転手IDだけで検索した場合の例は `POST /api/candidates/999999999991/take`、本文 `{"driverId":"demo-driver"}` です。サーバーは最新の保存済み掲載とボードで再計算し、登録できれば200と `{revision,trip}` を返します。

登録した便には `tentative:true` と `listingId` が入り、`agreement` は null です。ボードの積卸日時は成立した `pickupAt, deliveryAt` に合わせ、元の日時表記を便の `time` に残します。車を直接指定して登録した場合の担当は未定です。画面の操作名は「仮の便にする」とし、成功後は返された `trip.id` で便を開けます。通常の `kind:"trip"` 差分が他のボードにも届きます。候補一覧は再検索して更新してください。同じ荷物をもう一度登録する操作は、先に登録した便を削除した後も409になります。

| HTTP | 画面での取り扱い |
|---|---|
| 400 | 運転手ID・車両条件・前後の地名や日時、または管理者の単価入力を見直す |
| 401 / 403 | 未ログインは401。運転手のログインからは検索・仮便登録とも403。単価の設定は管理者だけが操作できる |
| 404 | 仮便登録時、指定番号の掲載が見つからないか掲載が終了。候補を再検索する |
| 409 | すでに仮便登録済み、または選択後に車・空きの条件が変わって成立しない。ボードと候補を読み直す |

## アプリの更新を確認して受け取る（管理者）

起動時に `--update-manifest <manifest.json の URL>` と `--update-key <公開鍵>` を両方指定すると、起動から2〜5分後に自動で確認します。以後は各回の確認後、5時間40分〜6時間20分の間で次の時刻を選びます。どちらか一方でも省略したときは `enabled:false` になり、通信もタイマー登録も行いません。公開鍵は Ed25519 の raw 32 バイトを標準の base64 にした文字列です。現在版はアプリフォルダーの1つ上の `version.json` の `version` を読み、ファイルがない開発環境では `0.0.0.0` を返します。

| 入口 | 管理画面での使い方 |
|---|---|
| `GET /api/admin/update` | 現在の確認・受信状態を読みます。配布元への通信は発生しません。 |
| `POST /api/admin/update/check` | 今すぐ確認し、完了後に200と現在の状態を返します。署名等の失敗は `lastFailure` で確認できます。手動確認はサーバー単位で1分に1回です。制限中は429と残り秒数の `Retry-After` を返します。 |
| `POST /api/admin/update/download` | 確認済みの候補を受信し、保存が完了すると200と現在の状態を返します。受信中はGETで進捗を読めます。候補なし、候補の変更、共有保存先にすでに新版がある場合は409です。通信・検証・保存の失敗時は502と失敗状態を返します。受け取り済みの同じZIPはディスクで検証して再利用します。 |

両方のPOSTの本文は空または `{}` です。管理者のログインが必要です。未ログインは401、配車係・運転手は403です。確認済みの候補がある間は、管理者の `GET /api/state` にも `"update":{"available":true,"version":"2026.11.26.1"}` が付きます。

確認済み・受信前の状態例です。

```json
{
  "enabled": true,
  "current": "2026.11.25.3",
  "checkedAt": "2026-11-26T05:02:00.000Z",
  "lastFailure": null,
  "available": {
    "version": "2026.11.26.1",
    "publishedAt": "2026-11-26T05:00:00Z",
    "notes": "配車画面を更新しました。",
    "bytes": 12345
  },
  "download": null
}
```

初回確認前は `checkedAt:null`、候補がないときは `available:null` です。現在版が配布元の `minFrom` を下回ると `reason:"MANUAL_UPDATE_REQUIRED"` が付きます。この場合は管理者に手動での入れ直しを案内してください。確認に失敗した場合は候補を取り消し、`lastFailure` に `{code,at}` を返します。`NETWORK` は通信・HTTP応答、`SIGNATURE` は署名、`SHAPE` は内容・形式の不一致です。失敗が続いても定期確認は続き、確認が成功すると `lastFailure` は null に戻ります。

`download` は受信を始めると `{state,received,bytes}` になります。`received` は受信済みバイト数、`bytes` は署名済みの予定バイト数です。`state` は受信中が `downloading`、引き渡し可能が `ready`、失敗が `failed` です。失敗時の `code` は `NETWORK`（通信）、`REDIRECT`（転送先・回数）、`SIZE`（サイズ）、`HASH`（SHA-256）、`STORAGE`（保存先）、`SHAPE`（不正な項目）、`SUPERSEDED`（共有保存先で新版が先に完成）のいずれかです。

### 配布元とランチャーの取り決め

`manifest.json` と、同じパスの末尾に `.sig` を付けた署名ファイルは、それぞれ直接200で取得できるURLに置きます。署名はUTF-8のマニフェストのバイト列全体（空白・末尾の改行を含む）に対するEd25519署名をbase64で1行にします。確認全体の期限は15秒、各ファイルの上限は64 KiBです。User-Agent は `routedesk-update` 固定で、要求には会社・利用者・端末の識別子やインストール済みの版を追加しません。

マニフェストでは `format:1`、`product:"routedesk"` を指定します。`version` と `minFrom` はドット区切りの4つの整数を左から数値で比較します。`publishedAt` はタイムゾーンを含む日時、`notes` は最大512文字の表示用テキストです。`file` には `name,url,bytes,sha256` の4項目を入れます。ファイル名は半角英数字・ピリオド・下線・ハイフンの1〜80文字に拡張子 `.zip` を付けます。Windowsの予約デバイス名は使えません。

ZIPのURLと各転送先は、マニフェストと同じ配布元、または `github.com`・`objects.githubusercontent.com`・`release-assets.githubusercontent.com` のHTTPSです。試験用HTTPはループバックの `127.0.0.1` と `[::1]` のみです。転送は3回まで、ZIPは400 MiBまでです。署名済みのバイト数とSHA-256の両方が一致した時点で、ZIPと `ready.json` が `<データの親>.updates/<version>/` にそろいます。新しい版の公開後に、この保存先にある古い版フォルダーを削除します。

`ready.json` の `version` は版の文字列、`file` は同じフォルダーのZIPのファイル名、`sha256` はZIP、`manifestSha256` は検証したマニフェストのバイト列のSHA-256（小文字の16進64桁）です。ランチャーはこの印を読み、アプリの入れ替えを担当します。
