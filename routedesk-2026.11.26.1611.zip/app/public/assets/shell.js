export async function api(path, {method = 'GET', json, headers, body} = {}) {
  const options = {method, credentials:'same-origin', cache:'no-store', headers:{...headers}};
  if (json !== undefined) {
    options.headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify(json);
  } else if (body !== undefined) options.body = body;
  const response = await fetch(path, options);
  const result = await response.json();
  if (!response.ok) {
    const error = new Error(result.error || '処理を完了できませんでした。');
    error.status = response.status;
    throw error;
  }
  return result;
}

if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
window.addEventListener('pageshow', event => { if (event.persisted) location.reload(); });
const sessionEvents = 'BroadcastChannel' in window ? new BroadcastChannel('haishashitsu-account') : null;
sessionEvents?.addEventListener('message', () => {
  // A shared device may have a second protected screen open in another tab.
  document.body.replaceChildren();
  location.replace('/');
});
document.querySelector('#hs-login')?.addEventListener('submit', async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = document.querySelector('#hs-message');
  const button = form.querySelector('button');
  if (button.disabled) return;
  button.disabled = true;
  message.textContent = '';
  try {
    const {user} = await api('/api/login', {method:'POST', json:{id:form.elements.id.value, password:form.elements.password.value}});
    form.elements.password.value = '';
    sessionEvents?.postMessage('login');
    location.replace(user.mustChangePassword ? '/password' : '/');
  } catch (error) {
    message.textContent = error.status ? error.message : '接続できません。通信を確認してください。';
    form.elements.password.focus();
    form.elements.password.select();
  } finally { button.disabled = false; }
});
document.querySelector('[data-hs-logout]')?.addEventListener('click', async event => {
  const button = event.currentTarget;
  button.disabled = true;
  try {
    await api('/api/logout', {method:'POST', json:{}});
    sessionEvents?.postMessage('logout');
    location.replace('/');
  } catch (error) {
    if (error.status === 401) return location.replace('/');
    button.disabled = false;
    window.alert('ログアウトできませんでした。通信を確認してください。');
  }
});
