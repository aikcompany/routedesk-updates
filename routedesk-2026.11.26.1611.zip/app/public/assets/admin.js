import {api} from './shell.js';
import {mountMasters} from './masters.js';
import {mountInvoiceSettings} from './invoice-settings.js';

const byId = id => document.getElementById(id);
const create = byId('hs-create');
const settings = byId('hs-settings');
const message = byId('hs-message');
const issued = byId('hs-issued');
const roles = {admin:'管理者', dispatcher:'配車係', driver:'運転手'};
let storedCompany;
function syncCompany(values, submitted = {}) {
  const next = {companyName:values.companyName || '', garage:values.garage || ''};
  for (const key of Object.keys(next)) {
    const field = settings.elements[key];
    if (!storedCompany || field.value === storedCompany[key] || field.value === submitted[key]) field.value = next[key];
  }
  storedCompany = next;
  document.querySelector('.hs-brand span').textContent = next.companyName || 'routedesk';
}
const billing = mountInvoiceSettings({report, saved:syncCompany});
let driverNames = new Map();
let users = [];
const own = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);

function report(error) {
  if (error.status === 401 || error.status === 403) return location.replace('/');
  message.textContent = error.status ? error.message : '接続できません。通信を確認してください。';
}
async function showPassword(result) {
  byId('hs-issued-for').textContent = result.user.displayName + '（' + result.user.id + '）';
  byId('hs-password').textContent = result.temporaryPassword;
  issued.showModal();
  await new Promise(resolve => issued.addEventListener('close', resolve, {once:true}));
}
function setDriverField() {
  const isDriver = create.elements.role.value === 'driver';
  byId('hs-driver-field').hidden = !isDriver;
  create.elements.driverId.required = isDriver;
  create.elements.driverId.disabled = !isDriver;
}
function button(label, handler) {
  const element = document.createElement('button');
  element.type = 'button';
  element.textContent = label;
  element.addEventListener('click', () => handler(element));
  return element;
}
async function loadUsers() {
  ({users} = await api('/api/admin/users'));
  renderUsers();
}
function renderUsers() {
  const rows = users.map(user => {
    const row = document.createElement('li');
    const info = document.createElement('div');
    const detail = document.createElement('small');
    info.textContent = user.displayName;
    detail.textContent = [user.id, roles[user.role], driverNames.get(user.driverId), user.disabled ? '停止中' : ''].filter(Boolean).join(' ・ ');
    info.append(detail);
    row.append(info);
    if (!user.disabled) {
      for (const [action, label] of [['reset','パスワード再発行'],['disable','利用停止']]) {
        row.append(button(label, element => {
          if (window.confirm(user.displayName + ' の' + label + 'を実行しますか？')) editUser({action, id:user.id}, element);
        }));
      }
    }
    return row;
  });
  byId('hs-users').replaceChildren(...rows);
}
async function editUser(data, submit) {
  if (submit.disabled) return;
  submit.disabled = true;
  message.textContent = '';
  try {
    const result = await api('/api/admin/users', {method:'POST', json:data});
    if (own(result, 'temporaryPassword')) {
      // Self-reset revokes this session. Preserve the one-time result until
      // the administrator closes the dialog, even when the next read gets 401.
      await showPassword(result);
    } else message.textContent = '利用を停止しました。';
    if (data.action === 'create') { create.reset(); setDriverField(); }
    await loadUsers();
  } catch (error) { report(error); }
  finally { submit.disabled = false; }
}
issued.addEventListener('close', () => {
  byId('hs-password').textContent = '';
  byId('hs-issued-for').textContent = '';
});
create.elements.role.addEventListener('change', setDriverField);
setDriverField();
create.addEventListener('submit', event => {
  event.preventDefault();
  editUser({action:'create', ...Object.fromEntries(new FormData(create))}, create.querySelector('button'));
});
settings.addEventListener('submit', async event => {
  event.preventDefault();
  const submit = settings.querySelector('button');
  if (submit.disabled || !storedCompany) return;
  submit.disabled = true;
  try {
    const changes = Object.fromEntries([...new FormData(settings)].filter(([key,value]) => value !== storedCompany[key]));
    if (Object.keys(changes).length) {
      const {settings:values} = await api('/api/admin/settings', {method:'POST', json:changes});
      syncCompany(values, changes);
      billing.setCompanyName(values.companyName);
    }
    message.textContent = '会社設定を保存しました。';
  } catch (error) { report(error); }
  finally { submit.disabled = false; }
});
async function loadSettings() {
  const {settings:values} = await api('/api/admin/settings');
  syncCompany(values);
  billing.load(values);
  const config = values.import.agreements;
  importForm.elements.enabled.checked = config.enabled;
  importForm.elements.sourceDir.value = config.sourceDir;
  importForm.elements.sourceDir.required = config.enabled;
}
function driversChanged(drivers) {
  driverNames = new Map(drivers.map(d => [d.id, d.name]));
  renderUsers();
  const select = create.elements.driverId;
  const previous = select.value;
  select.replaceChildren(new Option('選んでください', ''),
    ...drivers.filter(d => !d.disabled).map(d => new Option(d.name, d.id)));
  if ([...select.options].some(opt => opt.value === previous)) select.value = previous;
}
const importForm = byId('hs-import-form');
importForm.elements.enabled.onchange = () => { importForm.elements.sourceDir.required = importForm.elements.enabled.checked; };
async function loadStatus() {
  const {agreements:s} = await api('/api/admin/status');
  const date = value => new Date(value).toLocaleString('ja-JP');
  const lines = [s.lastSuccessAt ? '最終成功 ' + date(s.lastSuccessAt) + '（追加 ' + s.lastAdded + ' 件）' : '成功した取り込みはまだありません。'];
  if (s.error) lines.push('最終試行 ' + date(s.lastAttemptAt) + '　' + s.error);
  byId('hs-import-status').textContent = lines.join('\n');
}
byId('hs-refresh-status').onclick = () => loadStatus().catch(report);
importForm.onsubmit = async event => {
  event.preventDefault();
  if (importForm.inert) return;
  importForm.inert = true;
  try {
    const agreements = {enabled:importForm.elements.enabled.checked, sourceDir:importForm.elements.sourceDir.value.trim()};
    await api('/api/admin/settings', {method:'POST', json:{import:{agreements}}});
    message.textContent = '取り込み設定を保存しました。';
    await loadStatus();
  } catch (error) { report(error); }
  finally { importForm.inert = false; }
};
await Promise.all([loadUsers(), loadSettings(), loadStatus(), mountMasters({
  report, announce:text => { message.textContent = text; }, showPassword, driversChanged, usersChanged:loadUsers,
})]).catch(report);
