// FAX 送付状: 上の欄 → 下の紙面。印刷するだけで、どこにも送らない。
const form = document.querySelector('.fx-tools');
const presets = JSON.parse(form.dataset.presets);
const input = key => form.querySelector(`[data-in="${key}"]`);
const out = key => document.querySelector(`[data-out="${key}"]`);
const rows = [...document.querySelectorAll('.fx-body [data-row]')];

function draw() {
  for (const key of ['toName', 'honorific', 'toTel', 'toFax', 'pages', 'subject', 'staff']) out(key).textContent = input(key).value;
  const d = input('date').value;
  if (/^\d{4}-\d{2}-\d{2}$/.test(d)) out('date').textContent = `${Number(d.slice(0, 4))}年 ${Number(d.slice(5, 7))}月 ${Number(d.slice(8, 10))}日`;
  for (const box of form.querySelectorAll('[data-in^="check-"]')) out(box.dataset.in).textContent = box.checked ? '✓' : '';
  const lines = input('body').value.split('\n');
  rows.forEach((row, i) => { row.textContent = i < rows.length - 1 ? lines[i] ?? '' : lines.slice(i).join(' '); });
  document.title = 'FAX送付状' + (input('toName').value ? ' ' + input('toName').value : '');
}

form.addEventListener('input', event => {
  if (event.target === input('preset')) {
    const p = presets.find(x => x.id === input('preset').value);
    if (p) { input('subject').value = p.subject; input('body').value = p.body; input('pages').value = p.pages; }
  }
  draw();
});
form.addEventListener('submit', event => event.preventDefault());
form.querySelector('[data-print]').addEventListener('click', () => window.print());
draw();
