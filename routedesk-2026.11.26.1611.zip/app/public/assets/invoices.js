import {api} from './shell.js';

const query = new URLSearchParams(location.search);
const form = document.getElementById('hs-invoice-month');
const content = document.getElementById('hs-invoice-content');
const message = document.getElementById('hs-invoice-message');
const allLink = document.getElementById('hs-invoice-all');
const thisMonth = new Intl.DateTimeFormat('sv-SE', {timeZone:'Asia/Tokyo', year:'numeric', month:'2-digit'}).format(new Date());
const month = /^\d{4}-(0[1-9]|1[0-2])$/.test(query.get('month') || '') ? query.get('month') : thisMonth;
const customerId = query.get('customerId');
const yen = amount => amount == null ? '未入力' : Number(amount).toLocaleString('ja-JP') + '円';
const day = value => value ? value.replaceAll('-', '/') : '';
const linkTo = (path, params = {}) => path + '?' + new URLSearchParams({month, ...params});
if (!form.elements.month.value) form.elements.month.value = month;

function element(tag, text, className) {
  const el = document.createElement(tag);
  if (text != null) el.textContent = text;
  if (className) el.className = className;
  return el;
}
function link(label, url, style) {
  const a = element('a', label, style);
  a.href = url;
  return a;
}
function table(caption, headers) {
  const wrap = element('div', null, 'hs-invoice-scroll');
  const el = document.createElement('table');
  el.setAttribute('aria-label', caption);
  const head = el.createTHead().insertRow();
  for (const title of headers) {
    const th = element('th', title);
    th.scope = 'col';
    head.append(th);
  }
  wrap.append(el);
  return {wrap, body:el.createTBody()};
}
function cell(row, value, className) {
  const td = row.insertCell();
  if (className) td.className = className;
  if (value instanceof Node) td.append(value);
  else td.textContent = value;
  return td;
}
function stateText(row) {
  if (row.changed) return '発行後に変わった';
  return row.latest ? '発行済み（第' + row.latest.version + '版）' : '未発行';
}
function printLink(label, params) {
  const a = link(label, linkTo('/invoices/print', params), 'hs-invoice-action');
  a.target = '_blank';
  a.rel = 'noopener';
  return a;
}
function renderList({invoices, summary}) {
  if (!invoices.length) {
    content.replaceChildren(element('p','この月の請求書はありません。','hs-invoice-empty'));
    return;
  }
  allLink.href = linkTo('/invoices/print');
  allLink.target = '_blank';
  allLink.rel = 'noopener';
  allLink.hidden = false;
  const panel = element('section', null, 'hs-invoice-panel');
  const heading = element('div', null, 'hs-invoice-heading');
  heading.append(element('h2','取引先別の請求'), element('p', '合計 ' + yen(summary.total), 'hs-bill-total'));
  const {wrap, body} = table('取引先別の請求', ['取引先','便の件数','請求額（税込）','確かめる所','発行の状況']);
  for (const row of invoices) {
    const tr = body.insertRow();
    const a = link(row.customer, linkTo('/invoices',{customerId:row.customerId}));
    cell(tr,a); cell(tr,row.count + '件','hs-invoice-num'); cell(tr,yen(row.total),'hs-invoice-num');
    cell(tr,row.issueCount + '件',row.issueCount ? 'hs-needs-check' : '');
    cell(tr,stateText(row),row.changed ? 'hs-needs-check' : '');
    tr.className = 'hs-invoice-row';
    tr.onclick = event => { if (!event.target.closest('a') && !getSelection()?.toString()) a.click(); };
  }
  panel.append(heading,wrap);
  content.replaceChildren(panel);
}

function linesPanel(inv) {
  const panel = element('section', null, 'hs-invoice-panel');
  panel.append(element('h2','便の明細'));
  const {wrap, body} = table('便の明細',['積んだ日','積地','卸地','車両ナンバー','運賃','高速代','請求書の備考']);
  for (const line of inv.lines) {
    const tr = body.insertRow();
    cell(tr,day(line.date)); cell(tr,line.from); cell(tr,line.to); cell(tr,line.plate || '—');
    cell(tr,yen(line.freightYen),'hs-invoice-num'); cell(tr,line.tollYen == null ? '—' : yen(line.tollYen),'hs-invoice-num');
    cell(tr,line.note,'hs-line-note');
  }
  panel.append(wrap);
  return panel;
}
function checksPanel(issues) {
  const panel = element('section', null, 'hs-invoice-panel');
  panel.append(element('h2','確かめる所（' + issues.length + '件）'));
  if (!issues.length) return panel;
  const ul = element('ul',null,'hs-invoice-checks');
  for (const issue of issues) {
    const li = element('li');
    li.append(element('span',day(issue.date) + '　' + issue.text),
      link('便を開く', '/?' + new URLSearchParams({trip:issue.tripId})));
    ul.append(li);
  }
  panel.append(ul);
  return panel;
}
function historyPanel(history) {
  const panel = element('section', null, 'hs-invoice-panel');
  panel.append(element('h2','発行の記録'));
  const {wrap, body} = table('発行の記録',['版','発行日','請求書番号','紙面']);
  for (const item of history) {
    const tr = body.insertRow();
    cell(tr,'第' + item.version + '版'); cell(tr,day(item.issueDate)); cell(tr,item.number);
    cell(tr,printLink('発行時の請求書を見る',{customerId,version:item.version}));
  }
  panel.append(wrap);
  return panel;
}

function renderDetail(detail) {
  const inv = detail.invoice;
  const head = element('section',null,'hs-invoice-panel');
  const heading = element('div',null,'hs-invoice-heading');
  heading.append(element('h2',inv?.customer || detail.customer || '発行済みの取引先'));
  if (inv) heading.append(element('p','請求額（税込） ' + yen(inv.total),'hs-bill-total'));
  head.append(heading);
  if (inv) head.append(element('p','対象期間　' + day(inv.period.start) + ' 〜 ' + day(inv.period.end) + '　｜　支払期限　' + day(inv.due)));
  if (detail.changed) head.append(element('p','発行後に変わった','hs-needs-check'));
  if (detail.latest) head.append(element('p','直近の発行　第' + detail.latest.version + '版　' + detail.latest.number + '　' + day(detail.latest.issueDate)));
  const back = link('月の一覧に戻る',linkTo('/invoices'),'hs-invoice-back');
  content.replaceChildren(back,head);
  if (inv) {
    const actions = element('div',null,'hs-invoice-actions');
    const current = {customerId};
    if (detail.latest && !detail.changed) current.version = detail.latest.version;
    actions.append(printLink('請求書を見る',current),printLink('印刷',{...current,print:1}));
    if (!detail.latest || detail.changed) {
      const issue = element('button',detail.latest ? '発行し直す' : '発行する','hs-primary');
      issue.type = 'button';
      issue.onclick = async () => {
        if (issue.disabled) return;
        issue.disabled = true;
        message.textContent = '';
        try {
          const result = await api('/api/invoices/issue', {method:'POST',json:{customerId,month,expectedVersion:detail.latest?.version ?? 0}});
          message.textContent = '第' + result.version + '版を発行しました。請求書番号 ' + result.number;
          await loadDetail();
        } catch (error) {
          report(error);
          if (error.status === 409) await loadDetail().catch(report);
        } finally { issue.disabled = false; }
      };
      actions.append(issue);
    }
    head.append(actions);
    content.append(checksPanel(inv.issues),linesPanel(inv));
  } else head.append(element('p','この月に請求する便はありません。'));
  if (detail.history.length) content.append(historyPanel(detail.history));
}
function report(error) {
  if (error.status === 401 || error.status === 403) { location.replace('/'); return; }
  message.textContent = error.status ? error.message : 'つながりませんでした。ルートデスクを開き直してください。';
}
async function loadDetail() {
  renderDetail(await api('/api/invoices/' + encodeURIComponent(customerId) + '/' + month));
}
try {
  if (customerId) await loadDetail();
  else renderList(await api(linkTo('/api/invoices')));
} catch (error) {
  content.replaceChildren(link('月の一覧に戻る',linkTo('/invoices')));
  report(error);
} finally { content.setAttribute('aria-busy','false'); }
