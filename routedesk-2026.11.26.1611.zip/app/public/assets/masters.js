import {api} from './shell.js';

function makeButton(text, type = 'button') {
  const button = document.createElement('button');
  button.type = type;
  button.textContent = text;
  return button;
}

export async function mountMasters({report, announce, showPassword, driversChanged, usersChanged}) {
  const merge = document.getElementById('hs-merge');
  let merging;
  merge.querySelector('[data-cancel]').onclick = () => merge.close();
  merge.querySelector('form').onsubmit = async event => {
    event.preventDefault();
    if (!merging || merge.inert) return;
    merge.inert = true;
    try {
      await merging(event.target.elements.target.value);
      merge.close();
      announce('取引先をまとめました。');
    } catch (error) { merge.close(); report(error); }
    finally { merge.inert = false; }
  };

  async function mount(kind) {
    const driver = kind === 'drivers';
    const section = document.getElementById('hs-' + kind);
    const add = section.querySelector('[data-add]');
    const tbody = section.querySelector('tbody');
    const records = new Map();
    const endpoint = '/api/admin/' + kind;
    let draft = null;
    add.disabled = true;
    const sync = () => {
      section.querySelector('[data-empty]').hidden = !!tbody.rows.length;
      section.querySelector('table').hidden = !tbody.rows.length;
      if (driver) driversChanged([...records.values()]);
    };

    function render(record = {}) {
      const fresh = !record.id;
      const row = document.createElement('tr');
      const form = document.createElement('form');
      form.id = 'hs-row-' + crypto.randomUUID();
      const fields = {};
      function cell() {
        return row.insertCell();
      }
      function field(parent, key, title, type = 'text') {
        const label = document.createElement('label');
        label.className = type === 'checkbox' ? 'hs-check' : 'hs-cell-field';
        const caption = document.createElement('span');
        caption.textContent = title;
        const tag = type === 'select' || type === 'textarea' ? type : 'input';
        const input = document.createElement(tag);
        if (tag === 'input') input.type = type;
        input.setAttribute('form', form.id);
        input.name = key;
        if (type === 'checkbox') {
          input.checked = !!record[key];
          label.append(input, caption);
        } else {
          input.value = record[key] ?? '';
          label.append(caption, input);
        }
        parent.append(label);
        fields[key] = input;
        return input;
      }
      const name = field(cell(), 'name', driver ? '運転手名' : '取引先名');
      name.required = true;
      if (driver) {
        field(cell(), 'vehicle', '車番');
        field(cell(), 'plate', 'ナンバー全体');
        const tons = field(cell(), 'tons', '積載量（t）', 'number');
        tons.min = '0'; tons.step = 'any';
        field(cell(), 'body', '車体');
      } else {
        field(cell(), 'reading', 'よみ');
        field(cell(), 'honorific', '敬称').value = record.honorific ?? '御中';
        for (const [key, label] of [['closingDay','締め日'],['payMonthOffset','支払いの月'],['payDay','支払日']]) {
          if (key === 'payMonthOffset') {
            const months = field(cell(), key, label + '（0は当月、1は翌月）', 'number');
            months.min = '0'; months.max = '120'; months.step = '1';
            months.placeholder = '会社設定';
            months.title = '締めた月から何か月後かを入力。空欄なら会社設定を使います。';
            months.value = record.invoice?.[key] ?? '';
          } else {
            const day = field(cell(), key, label, 'select');
            day.add(new Option('会社設定', ''));
            day.add(new Option('月末', '0'));
            for (let i = 1; i <= 31; i++) day.add(new Option(i + '日', String(i)));
            day.value = record.invoice?.[key] ?? '';
          }
        }
        const memo = field(cell(), 'memo', 'メモ', 'textarea');
        memo.rows = 2;
        memo.maxLength = 4000;
        memo.title = 'Enterで保存、Shift＋Enterで改行';
        memo.onkeydown = event => {
          if (event.key === 'Enter' && !event.shiftKey && !event.isComposing && event.keyCode !== 229) {
            event.preventDefault();
            form.requestSubmit();
          }
        };
      }
      const flags = cell();
      if (driver) field(flags, 'offDuty', '休み', 'checkbox');
      field(flags, 'disabled', '使わない', 'checkbox');
      const actions = cell();
      if (fresh && driver) {
        const issue = field(actions, 'issue', 'この人のログインも作る', 'checkbox');
        const login = field(actions, 'loginId', 'ログイン ID');
        login.autocomplete = 'off';
        login.parentElement.classList.add('hs-login-id');
        const toggle = () => {
          login.disabled = !issue.checked;
          login.required = issue.checked;
          login.parentElement.hidden = !issue.checked;
        };
        issue.onchange = () => { toggle(); if (issue.checked) login.focus(); };
        toggle();
      }
      form.className = 'hs-actions';
      const save = makeButton(fresh ? '登録' : '保存', 'submit');
      form.append(save);
      actions.append(form);
      if (fresh) {
        const cancel = makeButton('戻る');
        cancel.onclick = () => { row.remove(); draft = null; sync(); add.focus(); };
        form.append(cancel);
      } else if (!driver) {
        const combine = makeButton('まとめる');
        combine.onclick = () => {
          const options = [...records.values()].filter(item => item.id !== record.id && !item.disabled);
          if (!options.length) { announce('まとめ先に使う取引先を先に登録してください。'); return; }
          document.getElementById('hs-merge-from').textContent = '「' + record.name + '」の便を、選んだ取引先にまとめます。';
          const target = merge.querySelector('select');
          target.replaceChildren(new Option('選んでください', ''), ...options.map(item => new Option(item.name, item.id)));
          merging = async mergeInto => {
            const {customer} = await api(endpoint, {method:'POST', json:{id:record.id, mergeInto}});
            records.delete(record.id);
            records.set(customer.id, customer);
            row.remove();
            sync();
          };
          merge.showModal();
        };
        form.append(combine);
      }
      form.onsubmit = async event => {
        event.preventDefault();
        if (row.inert) return;
        row.inert = true;
        try {
          const data = fresh ? {} : {id:record.id};
          for (const [key, input] of Object.entries(fields)) {
            if (key === 'issue' || input.disabled) continue;
            let value = input.value;
            if (input.type === 'checkbox') value = input.checked;
            if (!driver && ['closingDay','payMonthOffset','payDay'].includes(key)) {
              value = value === '' ? null : Number(value);
              if (value !== (record.invoice?.[key] ?? null)) (data.invoice ??= {})[key] = value;
              continue;
            }
            if (key === 'tons') value = value === '' ? null : Number(value);
            if (fresh || value !== record[key]) data[key] = value;
          }
          const result = await api(endpoint, {method:'POST', json:data});
          const saved = driver ? result.driver : result.customer;
          records.set(saved.id, saved);
          const savedRow = render(saved);
          row.replaceWith(savedRow);
          if (fresh) draft = null;
          sync();
          if (result.temporaryPassword) await showPassword(result);
          announce(fresh ? '登録しました。' : '保存しました。');
          if (fresh) add.click();
          else savedRow.querySelector('input').focus();
          if (driver) await usersChanged();
        } catch (error) { report(error); }
        finally { row.inert = false; }
      };
      return row;
    }
    add.onclick = () => {
      if (!draft) {
        draft = render();
        tbody.append(draft);
        sync();
      }
      draft.querySelector('input').focus();
    };
    const data = await api(endpoint);
    const query = new URLSearchParams(location.search);
    let focused;
    for (const record of data[kind]) {
      records.set(record.id, record);
      const row = render(record);
      tbody.append(row);
      if (!driver && query.get('customerName') === record.name) focused = row;
    }
    sync();
    add.disabled = false;
    if (!driver && query.get('newCustomer') === '1') add.click();
    else if (focused) focused.querySelector('input').focus();
  }
  await Promise.all([mount('drivers'), mount('customers')]);
}
